# DEPLOY-BOOTSTRAP-01 — workcell + status 系の配備指示(Claude Code 宛)

発行: Taka(経由: Claude web 起草)
位置づけ: BOOTSTRAP_EXCEPTION(帳簿記録対象)。本作業は「検証済み成果物の
搬入と実測」であり、実装ではない。
急務認識: 2DER で業務を動かすシステムを立ち上げること。過剰な整備より
「M1 が runner 経由で 1 回走る」到達を優先する。

---

## 0. あなた(Claude Code)への委任範囲と禁止事項

**委任する(あなたが実環境を知っているので、あなたが決める):**
- 配置先ディレクトリ・リポジトリ(2DER 系のどの repo に置くか。現状の
  実際の使われ方に合わせよ。理想論での再編成はしない)
- 実行ユーザ / パーミッション設計
- systemd unit の実環境適合(パス、vLLM への接続形態 — TCP か socket かは
  実際に動いている vLLM の形に合わせる。PrivateNetwork が実環境と衝突する
  なら緩和してよいが、緩和内容と理由を必ず逸脱として報告)
- config.json / packet の実パス埋め
- status 再生成の起動方式(systemd timer / cron どちらでも)

**禁止(違反は作業全体の無効):**
- D-1 次の 5 ファイルの内容変更。配置後に sha256 一致を実測し報告する:
    runner.py          c86ba8bfe9c9e4c3a53c1ac8691b5242d8cee69e5b614a580c9762e5ef2a57c7
    test_runner.py     ef9e2f1d13bf636a6f5351e6b6908214896c530994ad582151b35d046f7ff81d
    twoder_status.py   5375e53f18824ec1630624818086a4e0dfd82e2b61f8778c78719d909d0d7b5d
    M1.md              857e47d4fd5c840529e583356f8d21af0c1e44aac66d0d90e60cc5092b74d374
    test_emit_api.py   f3afb93812ed64be99c038422906c649cc7d57e145ecf95d80186f46f8d59308
  問題(バグ・環境不適合)を見つけた場合: **直さず報告して差し戻す**。
  これはあなたの監査職能である。
- D-2 emit_api.py を書かない。一行たりとも。M1 の実装者は Qwen(runner 経由)
  であり、これはパイプライン自体の positive control である。あなたが書いたら
  この検証全体が無意味になる。
- D-3 spec / immutable tests の「改善」をしない(D-1 と同じ扱い)。
- D-4 本指示書のスコープ外の作業(リファクタ、他タスク、ドキュメント整備等)
  をしない。気づきは全て報告に書く。

調整可能ファイル(実環境値の埋め込みのみ可、構造変更は不可):
workcell-runner@.service / example_packet_M1.json / config_example.json /
backlog_seed.jsonl(追記のみ可)

## 1. 作業内容(順に)

1. Taka が git push したファイル一式を受領し、sha256 を照合(D-1 の 5 件)。
2. 配置。どこに置いたかを全件記録(repo / path)。
3. runner の自己テストをサーバ上で実行:
   `python3 -m pytest test_runner.py -v` → 18/18 を実測(出力を artifact 保存)。
4. sandbox unit を実環境に適合させ、次の 6 項目を **unit 内から実測**し、
   各項目のコマンドと出力を artifact 保存:
   (a) 2DER 系 repo への write が失敗する
   (b) runs-root 以外への write が失敗する
   (c) 外部 network アクセスが失敗する
   (d) vLLM への接続だけが成功する
   (e) subprocess からの権限昇格が失敗する(例: 別 UID ファイルへの write)
   (f) symlink 経由の runs-root 外 write が失敗する
   ※ 未達項目があっても隠さず「未達 + 理由」で報告(fail-closed 報告歓迎、
     偽装合格は最悪の結果)
5. status 系設置: config に実 repo パスを埋め、1 回生成して HTML を確認、
   定期再生成を登録。閲覧 URL を報告。
6. backlog_seed.jsonl を配置し、本作業自体を
   `{"id":"DEPLOY-01","state":"IN_PROGRESS", ...}` として追記。
7. **M1 実行**: packet に実環境値を埋め、unit 経由で runner を起動。
   Qwen が emit_api.py を実装する。結果がどうであれ RESULT_PACKET と
   run_log を artifact として報告:
   - PASSED → bootstrap 窓の終了条件成立
   - BUDGET_EXHAUSTED / 各種違反 → それ自体が貴重な実測。**絶対に自分で
     実装して通さない(D-2)**。ログを添えて差し戻し。

## 2. 報告(DEPLOY_REPORT)

次を含む単一レポートを返す:
- 配置一覧(repo/path)・sha256 照合結果
- 逸脱一覧(unit 緩和・パス変更等、各理由付き)
- 手順 3/4/7 の artifact パス一覧と要約(生ログ添付)
- 気づき・懸念(スコープ外作業はせず、ここに書く)
- backlog 追記行

## 3. 判断に迷ったら

止めて Taka に聞く。推測で進めない。「動くはず」より「測った」を常に優先。
