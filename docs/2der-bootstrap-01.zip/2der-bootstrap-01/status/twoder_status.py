#!/usr/bin/env python3
"""twoder_status v0 — 2DER 状況ページの決定論生成(LLM 不使用)。

原則: ステータスは「書く」ものではなく「導出する」もの。
入力(すべて一次記録):
  - 各 repo の HEAD / dirty 状態(git 実査)
  - runs_root/*/RESULT_PACKET.json(workcell 実行結果)
  - backlog.jsonl(DE/ITEM/裁定の状態。append-only、同一 id は後勝ち)
出力: 単一 HTML + テキスト要約。生成時刻と入力 hash を刻印(検証可能)。

backlog.jsonl 行形式:
  {"id":"DE-0439a","kind":"LIFT","title":"...","state":"AWAITING_TAKA",
   "owner":"taka","ts":"..."}
state ∈ OPEN / IN_PROGRESS / AWAITING_TAKA / AWAITING_GPT / BLOCKED / DONE
"""
from __future__ import annotations

import hashlib
import json
import subprocess
import sys
import time
from html import escape
from pathlib import Path

STATE_ORDER = ["AWAITING_TAKA", "AWAITING_GPT", "BLOCKED", "IN_PROGRESS",
               "OPEN", "DONE"]


def sh(cwd: Path, *args) -> str:
    try:
        return subprocess.run(["git", *args], cwd=cwd, capture_output=True,
                              text=True, timeout=30).stdout.strip()
    except Exception as e:
        return f"ERROR: {e}"


def repo_state(path: Path) -> dict:
    if not (path / ".git").exists():
        return {"head": "NOT_A_REPO", "dirty": -1, "ahead_behind": "?"}
    head = sh(path, "rev-parse", "--short", "HEAD")
    dirty = sh(path, "status", "--porcelain")
    ab = sh(path, "rev-list", "--left-right", "--count", "HEAD...@{upstream}")
    return {"head": head, "dirty": len(dirty.splitlines()),
            "ahead_behind": ab.replace("\t", "/") if ab and "ERROR" not in ab else "-"}


def collect_runs(runs_root: Path, limit: int = 20) -> list[dict]:
    out = []
    if not runs_root.exists():
        return out
    for rp in sorted(runs_root.glob("*/RESULT_PACKET.json"), reverse=True)[:limit]:
        try:
            r = json.loads(rp.read_text(encoding="utf-8"))
            out.append({"run_id": r.get("run_id", rp.parent.name),
                        "task_id": r.get("task_id", "?"),
                        "status": r.get("status", "?"),
                        "iterations": r.get("iterations_used", "?")})
        except Exception as e:
            out.append({"run_id": rp.parent.name, "task_id": "?",
                        "status": f"UNREADABLE({e})", "iterations": "?"})
    return out


def collect_backlog(path: Path) -> list[dict]:
    latest: dict[str, dict] = {}
    if path.exists():
        for line in path.read_text(encoding="utf-8").splitlines():
            if line.strip():
                rec = json.loads(line)
                latest[rec["id"]] = rec  # append-only、後勝ち
    items = list(latest.values())
    items.sort(key=lambda r: (STATE_ORDER.index(r["state"])
                              if r["state"] in STATE_ORDER else 99, r["id"]))
    return items


def generate(config: dict) -> tuple[str, str]:
    now = time.strftime("%Y-%m-%dT%H:%M:%SZ", time.gmtime())
    repos = {n: repo_state(Path(p)) for n, p in config["repos"].items()}
    runs = collect_runs(Path(config["runs_root"]))
    backlog_path = Path(config["backlog"])
    backlog = collect_backlog(backlog_path)
    backlog_sha = (hashlib.sha256(backlog_path.read_bytes()).hexdigest()[:12]
                   if backlog_path.exists() else "absent")

    waiting = [b for b in backlog if b["state"].startswith("AWAITING")]
    active = [b for b in backlog if b["state"] in ("IN_PROGRESS", "OPEN", "BLOCKED")]

    # --- テキスト要約(端末/リレー用) ---
    lines = [f"# 2DER STATUS (derived, no-LLM) @ {now}",
             f"backlog sha256[:12]={backlog_sha}", "", "## repos"]
    for n, s in repos.items():
        lines.append(f"  {n:14s} {s['head']:12s} dirty={s['dirty']} sync={s['ahead_behind']}")
    lines.append("\n## awaiting adjudication")
    for b in waiting or [{"id": "-", "title": "(none)", "state": ""}]:
        lines.append(f"  [{b['state']:14s}] {b['id']:14s} {b['title']}")
    lines.append("\n## active items")
    for b in active or [{"id": "-", "title": "(none)", "state": ""}]:
        lines.append(f"  [{b['state']:14s}] {b['id']:14s} {b['title']}")
    lines.append("\n## recent workcell runs")
    for r in runs or [{"run_id": "-", "task_id": "(none)", "status": "", "iterations": ""}]:
        lines.append(f"  {r['run_id']:24s} {r['task_id']:16s} "
                     f"{r['status']:28s} it={r['iterations']}")
    text = "\n".join(lines)

    # --- HTML ---
    def table(rows, cols):
        h = "<tr>" + "".join(f"<th>{escape(c)}</th>" for c in cols) + "</tr>"
        for r in rows:
            h += "<tr>" + "".join(
                f"<td>{escape(str(r.get(c.lower().replace(' ', '_'), '')))}</td>"
                for c in cols) + "</tr>"
        return f"<table>{h}</table>"

    repo_rows = [{"repo": n, **s} for n, s in repos.items()]
    html = f"""<!doctype html><meta charset="utf-8">
<title>2DER status</title>
<style>body{{font-family:ui-monospace,monospace;margin:2rem;background:#111;
color:#ddd}}table{{border-collapse:collapse;margin:1rem 0}}
td,th{{border:1px solid #444;padding:4px 10px;text-align:left}}
th{{background:#222}}h2{{border-bottom:1px solid #333;padding-bottom:4px}}
.w{{color:#f6c445}}.d{{color:#7ec87e}}.b{{color:#e06c75}}
small{{color:#777}}</style>
<h1>2DER status <small>derived · no-LLM · {escape(now)}</small></h1>
<p><small>backlog sha256[:12]={escape(backlog_sha)} —
このページは一次記録から機械生成される。手書き更新は存在しない。</small></p>
<h2 class="w">裁定待ち ({len(waiting)})</h2>
{table(waiting, ["Id", "State", "Title", "Owner"])}
<h2>進行中 ({len(active)})</h2>
{table(active, ["Id", "State", "Title", "Owner"])}
<h2>repos</h2>
{table(repo_rows, ["Repo", "Head", "Dirty", "Ahead_behind"])}
<h2>workcell runs (直近)</h2>
{table(runs, ["Run_id", "Task_id", "Status", "Iterations"])}
<h2>完了 ({len([b for b in backlog if b['state']=='DONE'])})</h2>
{table([b for b in backlog if b["state"] == "DONE"], ["Id", "Title"])}
"""
    return text, html


def main():
    cfg = json.loads(Path(sys.argv[1]).read_text(encoding="utf-8"))
    text, html = generate(cfg)
    out = Path(cfg["out_html"])
    out.write_text(html, encoding="utf-8")
    print(text)
    print(f"\nhtml -> {out}")


if __name__ == "__main__":
    main()
