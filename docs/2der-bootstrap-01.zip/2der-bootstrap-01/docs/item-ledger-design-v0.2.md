# ITEM-LEDGER 設計 v0.2 — 帳簿ライフサイクル(GPT裁定反映版)

status: DRAFT v0.2(GPT裁定 3修正 ACCEPT 反映。Taka確認対象)
date: 2026-07-19
supersedes: item-ledger-design-v0.1.md
adjudication: 修正1(SUMMARIZABLE)/修正2(registry決定)/修正3(M1縮小)全て ACCEPT。
  等価性三分割・snapshot自己検査・CF-CLOSE-1..6・CLOSE決定論化・
  Web三フィールド分離・runner ceiling 確定も採用。

---

## 0. 大原則(改)

```
LG-1' 正典上の事実を無記録に消さない。原文を廃棄する場合も、その存在・
      範囲・hash・集約結果・廃棄根拠を永久記録する。
      (v0.1「削らない」の厳密化。全原文の永久保存は要求しない)
LG-2  締めは検証可能(§3 の三分割検査 + snapshot 自己検査)。
LG-3  アーカイブ済みセグメントは chain ごと保存。snapshot + chain で
      全履歴が再構成・検証可能(放置耐性)。
LG-S  封入フィールド原則(DE起票候補): 信頼に関与するメタデータ
      (retention_class / actor_instance / prompt_version / lane 等)は
      発行主体の自己申告値ではなく、コードが registry・呼出文脈から
      封入する。emitter の同名出力は常に無視する。
      根拠: GA-8(watcher metadata)と本件 retention_class で同一クラスの
      欠陥が2連続で観測された(DE-0045 同格の反復失敗パターン)。
```

## 1. 保持クラス(改・三分類)

```
PERMANENT    本文 + 検証 chain を恒久保存。DE / 裁定 / RESULT /
             CARRY_FORWARD / RETENTION_DISPOSITION。
CLOSEABLE    締め後に圧縮アーカイブへ移し、本文を保存。
             WAKE / OBSERVATION / RUN 等。
SUMMARIZABLE 個別本文は保持期限後に廃棄可能。ただし期間集計・件数・
             失敗数・hash commitment・保存方針・廃棄裁定を恒久保存。
             control / null / 大量低密度 telemetry 等。
             廃棄は無言で行わない:
             RETENTION_DISPOSITION {segment_id, event_count, root_hash,
               summary_hash, policy_ref, disposed_at} を必ず記帳。
```

## 2. retention_class の決定(修正2 — registry 決定・上書き不能)

```
LG-R1  retention_class は event kind registry(dev-workcell 登録、WS-6)の
       属性であり、イベント instance の自由入力ではない。
       例: WATCHER_WAKE→CLOSEABLE / WATCHER_CONTROL→SUMMARIZABLE /
           ENERGIZATION_ADJUDICATION→PERMANENT
LG-R2  emit 時: kind → registry lookup → retention_class 自動封入。
       worker / モデルからの retention_class 自己申告は無視(LG-S)。
LG-R3  クラス変更は個別イベントではなく承認済み policy version 経由のみ
       (POLICY 提案 → Taka 裁定 → registry 改版)。
```

## 3. 決算・繰越の検証(ITEM-LEDGER-LIFECYCLE で実装)

不変条件は三分割 + snapshot 自己検査:

```
STATE_EQUIVALENCE     replay(snapshot + active) == replay(full history)
CHAIN_CONTINUITY      active.first.prev_segment_root
                      == archived.last_segment_root
ARCHIVE_COMPLETENESS  manifest 記載の全 segment が存在し、各 sha と
                      root hash が一致
SNAPSHOT_SELF_CHECK   snapshot.state_hash
                      == replay(archived_segments).state_hash
                      (誤った起点からの内部整合を防ぐ)
```

counter-factual(締め機構の受け入れ条件):

```
CF-CLOSE-1 segment 1件欠落          → 検出
CF-CLOSE-2 segment 順序入替         → 検出
CF-CLOSE-3 snapshot 状態 1項目改竄  → 検出
CF-CLOSE-4 manifest の sha 差替え   → 検出
CF-CLOSE-5 previous_segment_root 切断 → 検出
CF-CLOSE-6 active 起点を旧 snapshot へ戻す → 検出
```

## 4. 職掌(修正 — 執行は LLM ではない)

```
LEDGER-POLICY        Qwen worker。実測(種別別成長率・参照頻度、帳簿から
                     導出)に基づく変更案の「提案記帳」のみ。
POLICY-ADJUDICATION  Taka 承認。
LEDGER-CLOSE EXECUTOR 決定論コード。承認済み policy の機械執行
                     (segment 選択 / replay / snapshot / 圧縮 / hash /
                     等価性検査 / carry-forward)。LLM を使わない。
CLOSE AUDITOR        別実装の決定論 replay 検査。必要時のみ Qwen / 別重みが
                     異常注釈。
管轄: EGL。初回締めは通電同型ゲート(Taka judo)、LG-2 実績蓄積後に
周期実行へ緩和(bridge と同じ昇格経路)。
```

## 5. M1 への即時適用(修正3 — 「将来決算しても形式が壊れない」まで)

M1 emit API に入れる:

```
- event kind registry(retention_class 属性込み)
- registry からの retention_class 自動封入・発行者上書き禁止(LG-R2)
- イベント形式: segment_id / sequence_in_segment / previous_event_hash /
  previous_segment_root / retention_class / schema_version
- M1 では単一 active segment のみ扱う
```

M1 に入れない: rotation daemon / 圧縮 / closing executor / carry-forward
生成 / POLICY worker / supervisor。

## 6. 別ITEM 分割(GPT 裁定どおり)

```
ITEM-LEDGER-LIFECYCLE   closing / archive / snapshot / carry-forward /
                        §3 検査群 / RETENTION_DISPOSITION。W1 実測後。
ITEM-WORKCELL-SUPERVISOR 上級機能。最初はコード決定表(packet route /
                        budget / retry 上限 / test result / timeout /
                        exception 分類 / escalation 先)。Qwen へ渡すのは
                        決定表で処理できない残余のみ。CC には置かない
                        (Taka 判断: 系固有ダイナミクスの観測を CC の
                        判断傾向で汚染しないため)。
ITEM-CONSULT-WORKER     CC 諮問。CONSULT_REQUEST / RESPONSE / ADOPTION /
                        REJECTION / OUTCOME の 5 分離で、助言の的中率・
                        領域別強みを事後測定可能にする。RESPONSE を決定と
                        して扱わない。
ITEM-WEB-RESEARCH-WORKER egress allow-list 付き別 sandbox。取得内容は
                        三フィールド分離:
                          raw_untrusted_blob_ref(参照のみ)
                          derived_facts(引用位置付き構造化 fact 候補)
                          instructions_from_source(構造的に破棄)
                        他 worker へ渡すのは原則 derived_facts のみ。
                        raw は命令と同一文字列面へ混ぜない。
                        注入面として JREV 初期対象。
```

## 7. runner v0.1 の位置(GPT 裁定確定)

```
ceiling: WORKCELL_RUNNER_V0_1_GATES_TESTED_ON_LOCAL_FIXTURES
禁止:    GENERATED_CODE_OS_CONFINED(配備実測まで)
残余リスク明記: WORKCELL_SANDBOXED=1 は環境変数であり手動偽装可能。
  実封じ込めは systemd unit の配備実測(対象repo write 失敗 / runs-root 外
  write 失敗 / 外部 network 失敗 / vLLM socket のみ成功 / subprocess 権限
  突破失敗 / symlink 経由 write 失敗)で証明する。= runner 次回 re-battle 対象。
```
