# Watcher Layer 設計提案 v0.2 — 系内感覚器(Qwen常駐・判断と書込みを持たない)

status: DRAFT v0.2(GPT監査 GA-1..10 裁定反映済み・Taka裁定前・構築ゼロ)
date: 2026-07-19
supersedes: watcher-layer-design-v0.1.md
adjudication: GA-1..5,7..10 ACCEPT / GA-4 ACCEPT-MOD / GA-6 PARTIAL
  (裁定表は本書付録A。Taka確認対象)
depends: DE-0344 / DE-0426 / DE-0429 / DE-0437 / RL-1..4 / EI-3 / FA-2
scope: 本書は Watcher 本体のみを扱う(GPT総合裁定準拠)。
  構成台帳の AST・意味層 = 別ITEM(§16)。
  Claude Code 職責 = Taka 恒久裁定(2026-07-19)の参照のみ、本書は制定しない(§14)。

---

## 0. 目的

系内の変更イベントを起点に起動する監視層。位置づけは「系内感覚器」:
変更が起きた事実を忘れず、見落としを観測可能にする。判断と書込みを
持たせず、まず感覚器だけを確実に作る(GPT総合裁定の表現を採用)。

Claude Code のプロンプト駆動起動に由来する常在的追従の不履行
(状態変化への非追従・常設指示の忘却)を、環境側の機構で代替する第一歩。

---

## 1. 非目標

```
NG-1  観測対象系(git working tree / repo history / EGL正典 /
      ENERGIZATION_LEDGER)への書込みは一切しない(W-R0)。
NG-2  Watcher は DE を正典起票しない。観測候補まで。
NG-3  Claude Code の職責定義は本書の対象外(Taka恒久裁定を参照、§14)。
NG-4  apply-semantics-v2(DE-0436)はスコープ外。
NG-5  Watcher 出力を根拠とする自動修復・自動commit・自動再実行は禁止(W-R2)。
NG-6  ライブURL等 materialized view の自動更新は W1 スコープ外。
      W1 は dependency declaration(§9.2)に基づく更新漏れ検知まで。
NG-7  構成台帳の AST symbol table / import graph / 意味層は W1 スコープ外
      (別ITEM、§16)。
NG-8  n=20 規模での統計的有意差 claim は行わない。W1 は記述統計のみ(GA-5)。
```

---

## 2. 書込み三分類(GA-1 裁定 — 「read-only」の再定義)

v0.1 の「Watcher全体read-only」は誤記述であった。正確には:

```
W-R0  観測対象への書込み禁止。
      git working tree / repo history / EGL正典 / ENERGIZATION_LEDGER /
      docs 正本を変更しない。
W-R1  派生観測ストアへの append のみ許可。
      WATCHER_* イベントログ / Watcher Run Ledger /
      構成 snapshot(as_of_commit 付き append。既存行の上書き禁止。
      一時生成物は atomic replace のみ可)。
W-R2  逆流禁止。派生ストアの内容を根拠とする対象系への自動書込み・
      commit・DE正典化を禁止する。
```

構成 snapshot は FS+git から決定的に再導出可能な導出ビューであり
第2 SoR ではない(RC-3 準用)。機械層と意味層は別ファイル・別schema
(意味層は本書スコープ外、§16)。

---

## 3. アーキテクチャ — 3層 + 二系統WAKE

```
[層1 WAKE — 決定論コード・二系統(GA-2 裁定)]
  EDGE:      git hook / inotify による即時 WAKE。
  SWEEP:     定時 polling で HEAD / tree hash / ledger offset /
             FS snapshot を EDGE と独立に再計算する検査経路。
             (障害時fallbackではなく hook を検査する独立観測者)
  RECONCILE: EDGE 未観測の SWEEP 差分を WAKE_ORPHAN として記録。
  出力: WATCHER_WAKE / WAKE_ORPHAN

[層2 MULL — Qwen 32B 並列]
  入力: WAKE の指す差分の bounded context のみ(種別ごとの上限、DD-W5')
  出力: インスタンスごとの生 WATCHER_OBSERVATION(全件・集計前)

[層3 AGGREGATE — 決定論コード]
  合議判定 / safety_disposition ルーティング / lane binding 検査 /
  dedupe / null・control 比率計算
  出力: WATCHER_CONSENSUS / WATCHER_EXCEPTION / WATCHER_DISAGREEMENT
```

---

## 4. 構造的制約(WS 規則・改)

```
WS-1a AST ゲート: emit 可能なのは単一 emit API 経由の WATCHER_* のみ。
      書込み関数・subprocess・shell・socket・dynamic import / eval / exec を
      静的に持たない。
WS-1b OS 権限制御(GA-3 裁定 — AST は検査層であり権限制御層ではない):
      - 観測対象 repo は read-only mount で参照
      - Watcher 専用 UID
      - 書込み可能 path は observation store のみ(OS 層で強制)
      - network deny 既定
      - symlink 追跡は realpath 検査で observation store 外を拒否
      - logging handler の出力先も observation store 内に固定
WS-2  fail-closed: スキーマ逸脱・応答異常・タイムアウト・空応答は
      WATCHER_EXCEPTION。既定は「観測失敗」であり「異常なし」ではない。
WS-3  bounded context(EI-3 準用)。段間コンテキスト分離。
WS-4  封入原則(GA-8 裁定): actor_instance / prompt_version / model /
      input_snapshot_hash / run_id は呼出側コードが封入する。
      Qwen 出力内の同名フィールドは層3 が読まない(自己申告排除)。
WS-5  enum 強制 + classification_residual(FA-2 準用)。自由文は層3 が読まない。
WS-6  WATCHER_* 種は dev-workcell 登録(DE-0402 前例)。第3 SoR にしない。
WS-7' 単調性は severity にのみ適用(GA-4 裁定):
      safety_disposition の自律的引き下げ・観測取り消しは発行不可。
      分類名(classification)の訂正・再分類は禁止しない。
```

V項目(実装前検証事項): V-W1 DE-0429 reconciler が実際に持つ OS 層制約の
一次確認(コード・mount 構成の実査。「同型の前例」主張は確認後まで保留)。

---

## 5. 役割インスタンス(W1A/W1B で段階投入)

```
[W1A]
ROLE-OBS   observer 1系統: 中立記述。
[W1B]
ROLE-CLS   classifier N=3(DD-W2: 3で開始。増強は同一重み内誤差の
           独立性実測後)。
ROLE-AUD-C consistency: コード生成の機械候補への注釈のみ(§9.1)。
ROLE-AUD-S scope: DE-0045 型兆候の注釈。
ROLE-NULL  二種(GA-5 裁定):
           NULL-N 意味を保った非異常イベント(誤警報率測定)
           NULL-B 因果・binding のみ破壊(構造異常の検出感度測定)
```

---

## 6. 合議と例外の分離(GA-4 裁定)

```
AG-1  classification_agreement(k/N)と safety_disposition を分離する。
AG-2  safety_disposition ∈ {PASSIVE_RECORD / REVIEW / URGENT_EXCEPTION}。
AG-3  単調昇格: 1インスタンスでも重大候補を出せば REVIEW 以上へ。
      引き下げには裁定パスが必要(WS-7')。
AG-4  分類名の不一致のみ(重大候補なし)は WATCHER_DISAGREEMENT として
      記録し、Taka キューへ流さない(PASSIVE_RECORD)。
AG-5  schema 異常・応答異常は従来どおり EXCEPTION(WS-2)。
```

---

## 7. イベントスキーマ(認証・冪等性込み、GA-8 裁定)

全イベント共通フィールド:

```
{schema_version, producer_version, run_id, source_process_id,
 sequence_no, dedupe_key, input_snapshot_hash, ts}
```

種別:

```
WATCHER_WAKE        {wake_id, trigger_kind, trigger_ref, lane}          [EDGE]
WAKE_ORPHAN         {orphan_id, sweep_ref, missed_change_ref, lane}     [SWEEP]
WATCHER_OBSERVATION {obs_id, wake_id, role, classification,
                     severity_proposal, classification_residual,
                     bounded_context_ref, lane}
                     + 封入metadata(actor_instance, prompt_version,
                       model — 呼出側付与、WS-4)                        [層2]
WATCHER_CONSENSUS   {cons_id, wake_id, obs_ids[], agreement,
                     final_classification, safety_disposition,
                     routed_to, lane}                                   [層3]
WATCHER_DISAGREEMENT{dis_id, wake_id, obs_ids[], lane}                  [層3]
WATCHER_EXCEPTION   {exc_id, wake_id, obs_ids[], reason_enum, lane}     [層3]
WATCHER_CONTROL     {ctrl_id, control_id, injected_ref, expected_route,
                     detected, latency, lane="control"}                 [層1+3]
```

```
EV-W1  lane ∈ {real / null_n / null_b / control} を全イベント必須とする。
       lane は層1 が封入し、層2/層3 は変更不可(GA-9)。
EV-W2  dedupe: 層3 は同一 (wake_id, role, actor_instance, prompt_version)
       の重複 obs を拒否する。
EV-W3  CONSENSUS / EXCEPTION / DISAGREEMENT は obs_ids から決定的に
       再導出可能(受け入れ試験に含む)。
```

---

## 8. lane 隔離(GA-9 裁定)

```
LN-1  control 注入は non_canonical fixture / throwaway_target のみを対象とし、
      実 repo・実台帳へ擬似変更を入れない。
LN-2  control / null lane のイベントは DE 候補・Taka 例外キューへ
      構造的に到達不能とする(routed_to の許容値を lane で制限)。
LN-3  lane binding の検査は層3 の決定論コードが行う。
```

---

## 9. 契約駆動の整合検査(GA-7 裁定)

### 9.1 機械候補 → Qwen 注釈

コード側が機械的候補を enum で生成し、Qwen は注釈のみ:

```
HEAD_CHANGED / PATCH_APPLICATION_NOT_FOUND / DE_REFERENCE_NOT_FOUND /
HANDOFF_HEAD_MISMATCH / SNAPSHOT_COUNT_MISMATCH
```

「どの repo・どの変更 class で DE が必要か」は契約(§9.2)に依存し、
Qwen の常識判断に委ねない。

### 9.2 dependency declaration(前提条件)

```
DP-1  「event kind X → materialized view Y は更新義務を持つ」を
      機械可読の宣言として保持する(例: HEAD前進 → 管理ページ /
      handoff の鮮度義務)。
DP-2  更新漏れ検知は DP-1 宣言と実状態の突合のみから発火する。
      宣言なき義務の推測検知は禁止。
DP-3  DP 宣言の初期セットは Taka 承認を要する(何が義務かは組織判断)。
```

---

## 10. 常設検証と指標(GA-5 裁定で分離計測)

```
PC-1  positive control 常設(lane=control、LN-1 制約下)。
PC-2  null 二系統常設。
指標(すべて一次記録から導出・W1 は記述統計):
  wake 完全性        : EDGE↔SWEEP 突合(WAKE_ORPHAN 数)。
                       ※ WAKE_COMPLETENESS_MEASURED はこの突合の
                         実装後にのみ主張可(GA-2)
  positive-control recall
  benign-null false-positive rate(NULL-N)
  binding-null detection rate(NULL-B)
  major-event miss count
  classification_agreement 分布 / DISAGREEMENT 率
  CC 監査差分率 / Taka 棄却率
```

---

## 11. 重み跨ぎ監査(CA 規則・改)

```
CA-1  Claude Code は Watcher 出力のサンプリング監査者。
      監査比率(DD-W3'): 最初の50件は CONSENSUS 20% + EXCEPTION 100%、
      以後 CC 差分率に基づき調整(GPT 裁定案採用)。
CA-2  監査対象選定はコード側乱数(シード記録)。
CA-3' CC は構造化 finding を返すのみ。Run Ledger への記録は監査ハーネス
      (コード)が行う。CC による直接書込みは行わない(GA-6 裁定 —
      「監査のみ」との整合)。
CA-4  感度は過検出側(非対称コスト)。
```

---

## 12. 受け入れ試験と counter-factual(W1A/W1B ゲート)

W1A 合格条件(DD-W1' 初期ゲート、GPT 裁定案採用):

```
重大イベント見逃し 0 / schema 異常の正常扱い 0 /
positive-control recall 100% / benign-null 誤警報率は記録のみ /
軽微分類正答率は参考値
A-1  垂直スライス: 実変更1件 → EDGE WAKE → SWEEP 突合0 orphan →
     ROLE-OBS 観測 → 記録。
A-3  集計の決定的再導出検査(EV-W3)。
CF-1 合成変更(throwaway)→ WAKE するか
CF-2 ゴミイベント → EXCEPTION(fail-closed)
CF-6 タイムアウト/空応答 → EXCEPTION
CF-7 control イベントを real lane として再生 → lane binding 不一致で拒否
CF-8 real イベントを null/control lane へ偽装 → source binding 不一致で拒否
```

W1B 追加合格条件:

```
A-2  既知イベント列(過去実イベント採取、n=20)の分類測定(記述統計のみ)
A-4  MODEL_ROUTING_READY(watcher 役割)= A-2 + fail-closed 挙動合格
CF-3 層2 を経ない OBSERVATION 直接 emit → 単一 emit API + OS 層が拒否
CF-4 disposition 引き下げ・観測取り消し発行 → WS-7' が拒否
CF-5 層2 に集計済み CONSENSUS を騙らせる → 層3 再導出で不一致検出
CF-9 封入 metadata の Qwen 出力上書き試行 → 層3 が無視(WS-4)
```

---

## 13. re-battle(JREV-0011、W1B 終端)

DE-0426 準拠。想定攻撃面(v0.1 に GA 由来を追加):

```
- bounded context 迂回による嘘分類・嘘 severity
- WAKE 抑止(EDGE の死角)+ SWEEP 同時盲目化の試行
- lane 混線(CF-7/8 の変形)
- 封入 metadata の偽装経路探索(WS-4 の迂回)
- dedupe_key 衝突による観測握り潰し
```

adjudicator = GPT(Taka リレー)。

---

## 14. Claude Code 職責(参照のみ — 本書は制定しない、GA-6 裁定)

Taka 恒久裁定(2026-07-19): Claude Code の職責は重み跨ぎ監査のみ。
実装は 2DER 系(Qwen 経由)以外を全面禁止。Qwen 不能 = 構造的欠陥として
DE 起票し委譲で迂回しない。例外議論は再開しない。

```
本書内の操作規則: CC-W1 = W1 実装生成は Qwen worker のみ。Claude Code は
W1 成果物の重み跨ぎ監査を担当し、対象コードを直接修正しない(CA-1..4)。
推奨: 上記恒久裁定自体の正典化 DE を別途起票し、本書・handoff・メモリは
それを参照する(裁定内容の再審ではない。トレーサビリティ確保のみ)。
```

---

## 15. claim ceiling 語彙

```
許可: WATCHER_W1A_WAKE_PATH_TESTED / WAKE_ORPHAN_RECONCILIATION_BUILT /
      WATCHER_READONLY_DERIVED_STORE_APPEND_ONLY_VERIFIED /
      CONTROL_INJECTION_DETECTED_ON_TESTED_LANE /
      NULL_RATES_RECORDED(記述統計)
禁止: AMBIENT_MONITORING_PROVEN / WAKE_COMPLETENESS_MEASURED
      (EDGE↔SWEEP 突合の実装・実測前)/ CLAUDE_CODE_DEPENDENCY_REMOVED /
      WATCHER_CANNOT_BE_DECEIVED / ALL_CHANGE_PATHS_COVERED /
      NULL_SEPARATION_SIGNIFICANT(n 不足の間)
```

---

## 16. 別ITEM へ分離(GA-10 裁定)

```
ITEM-SL-A  最小構成 snapshot {repo, commit, path, sha256, file_count}
           → W1B に含める(W1b 相当)。
ITEM-SL-B  AST symbol table / import graph → 別ITEM。
ITEM-SL-C  意味層(Qwen 注釈による機能単位紐づけ)→ 別ITEM。
           Claude Code / 系の探索コスト削減効果を測定指標に持つ。
ITEM-URL   materialized view 自動更新(旧 DD-W6)→ W1 実測後の別裁定。
           watcher 発書込み class の要否もそこで扱う。
ITEM-LEDGER 帳簿ライフサイクル(決算・繰越・retention_class・
           POLICY/CLOSE worker 分離)→ item-ledger-design-v0.1.md。
           即時適用は LG-M1(M1 仕様へのセグメント化 + retention_class
           必須化)のみ。他は W1 実測後。
```

---

## 17. 部分解除 二段(GA 裁定採用 — DE-0439 案改)

```
LIFT-W1A(DE-0439a 案):
  EDGE wake / 独立 SWEEP / RECONCILE(WAKE_ORPHAN)/
  observation store(W-R1 準拠・OS 制約 WS-1b 込み)/
  ROLE-OBS 1系統 / 決定論ルーティング / control lane /
  CF-1,2,6,7,8 / auto-refreeze(terminal = §12 W1A 合格)
LIFT-W1B(DE-0439b 案・W1A 実測レビュー後):
  ROLE-CLS N=3 / AUD-C・AUD-S(§9 契約駆動)/ null 二系統 /
  CC sampling(CA-1..4)/ ITEM-SL-A / 全 CF / JREV-0011 /
  auto-refreeze(terminal = §12 W1B 合格 + JREV-0011 クローズ)
除外(両段共通): W-R0 対象への書込み一切 / bridge・minter 変更 /
  materialized view 自動更新 / Watcher 観測を入力とする自動アクション
実装者: Qwen worker(ladder/budget 規律下)。CC = 監査のみ(§14)。
```

---

## 18. DD(改・GPT 裁定案を初期値として採用、最終は Taka)

```
DD-W1' 初期ゲート = §12 W1A 条件(重大見逃し0 / schema異常正常扱い0 /
       control recall 100% / null 誤警報は記録のみ / 軽微正答率参考値)
DD-W2  N=3 開始。5 への増強は同一重み内誤差の独立性実測後。
DD-W3' 最初の50件: CONSENSUS 20% + EXCEPTION 100% → 以後 CC 差分率で調整。
DD-W4' SWEEP 周期(hook 検査経路として命名変更)。初期 5〜15 分、
       運用負荷実測で決定。
DD-W5' bounded context 上限をイベント種別ごとに定義(diff / ledger append /
       handoff 変更で別値)。
DD-W6  廃止 → ITEM-URL へ移管(W1 では決めない)。
DD-W7  DP-1 dependency declaration の初期セット(Taka 承認必須、§9.2)。
```

---

## 付録A 裁定表(GA-1..10)

```
GA-1  ACCEPT      W-R0/R1/R2 三分類。snapshot append / atomic replace 限定。
GA-2  ACCEPT      EDGE/SWEEP/RECONCILE。WAKE_COMPLETENESS_MEASURED は
                  突合実装後のみ(ceiling へ反映)。
GA-3  ACCEPT      WS-1b OS 権限制御追加。+ V-W1(DE-0429 実制約の一次確認)。
GA-4  ACCEPT-MOD  agreement/disposition 分離・単調昇格・WS-7' severity 限定。
GA-5  ACCEPT      NULL-N/B 分割・4指標分離・記述統計限定(NG-8)。
GA-6  PARTIAL     ACCEPT: 本書は CC 職責を制定せず参照へ(§14)。正典化 DE
                  別途起票を推奨。CC の Run Ledger 直接書込み廃止(CA-3')。
                  REJECT: 恒久裁定内容の再審は行わない(Taka 既決。GPT 指摘
                  もトレーサビリティ要求であり再審要求ではないと解する)。
GA-7  ACCEPT      機械候補 enum + Qwen 注釈のみ。DP-1..3 前提条件化。
GA-8  ACCEPT      認証・冪等 schema。封入原則 WS-4(Qwen 自己申告排除)。
GA-9  ACCEPT      lane binding LN-1..3。CF-7/8。キュー混入の構造的遮断。
GA-10 ACCEPT      W1a/W1b 分割。AST・意味層は別ITEM(§16)。
総合  ACCEPT      三概念の分離(Watcher 純化 / 構成台帳別ITEM / CC 職責参照化)。
                  「系内感覚器」の位置づけを §0 に採用。
```
