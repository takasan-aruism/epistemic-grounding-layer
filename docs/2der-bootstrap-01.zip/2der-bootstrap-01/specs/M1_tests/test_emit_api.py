"""M1 immutable tests — emit API 合否契約。作者: Claude(web)。
runner がこのファイルを workspace 外原本から供給する。実装者は変更不能。"""
import hashlib
import json
from pathlib import Path

import pytest

from emit_api import EventStore, EmitError

REG = {"WATCHER_WAKE": {"retention_class": "CLOSEABLE"},
       "WATCHER_CONTROL": {"retention_class": "SUMMARIZABLE"},
       "ENERGIZATION_ADJUDICATION": {"retention_class": "PERMANENT"}}


def store(tmp_path):
    return EventStore(tmp_path / "obs", REG, producer_version="m1-test")


def test_emit_seals_metadata(tmp_path):
    s = store(tmp_path)
    r = s.emit("WATCHER_WAKE", {"trigger": "hook"})
    assert r["retention_class"] == "CLOSEABLE"          # registry 由来
    assert r["segment_id"] == "seg-000001"
    assert r["sequence_in_segment"] == 0
    assert r["previous_event_hash"] == "0" * 64
    assert r["previous_segment_root"] == "0" * 64
    assert r["schema_version"] == "1"
    assert r["producer_version"] == "m1-test"
    assert r["lane"] == "real"
    r2 = s.emit("ENERGIZATION_ADJUDICATION", {"x": 1})
    assert r2["sequence_in_segment"] == 1
    assert r2["previous_event_hash"] == r["record_hash"]
    assert r2["retention_class"] == "PERMANENT"


def test_unknown_kind_fail_closed(tmp_path):
    s = store(tmp_path)
    with pytest.raises(EmitError):
        s.emit("MADE_UP_KIND", {})
    seg = tmp_path / "obs" / "seg-000001.jsonl"
    assert (not seg.exists()) or seg.read_text() == ""  # 書込み無し


@pytest.mark.parametrize("key", ["retention_class", "sequence_in_segment",
                                 "record_hash", "kind", "ts",
                                 "previous_event_hash", "schema_version"])
def test_sealed_key_in_payload_rejected(tmp_path, key):
    s = store(tmp_path)
    with pytest.raises(EmitError):
        s.emit("WATCHER_WAKE", {key: "attacker_value"})
    ok, _ = s.verify()
    assert ok  # 拒否後も帳簿は健全なまま


def test_invalid_lane_rejected(tmp_path):
    with pytest.raises(EmitError):
        store(tmp_path).emit("WATCHER_WAKE", {}, lane="banana")


def test_unserializable_payload_rejected(tmp_path):
    with pytest.raises(EmitError):
        store(tmp_path).emit("WATCHER_WAKE", {"f": object()})


def test_record_hash_and_verify(tmp_path):
    s = store(tmp_path)
    r = s.emit("WATCHER_WAKE", {"n": 1})
    body = {k: v for k, v in r.items() if k != "record_hash"}
    expect = hashlib.sha256(json.dumps(
        body, sort_keys=True, ensure_ascii=False).encode()).hexdigest()
    assert r["record_hash"] == expect
    s.emit("WATCHER_WAKE", {"n": 2})
    assert s.verify() == (True, "ok")


def test_verify_detects_tamper(tmp_path):
    s = store(tmp_path)
    s.emit("WATCHER_WAKE", {"n": 1})
    s.emit("WATCHER_WAKE", {"n": 2})
    seg = tmp_path / "obs" / "seg-000001.jsonl"
    lines = seg.read_text(encoding="utf-8").splitlines()
    rec = json.loads(lines[0])
    rec["payload"]["n"] = 999
    lines[0] = json.dumps(rec, ensure_ascii=False)
    seg.write_text("\n".join(lines) + "\n", encoding="utf-8")
    ok, why = s.verify()
    assert not ok


def test_reopen_continues_chain(tmp_path):
    s1 = store(tmp_path)
    a = s1.emit("WATCHER_WAKE", {"n": 1})
    s2 = store(tmp_path)  # 別インスタンスで再開(放置耐性)
    b = s2.emit("WATCHER_WAKE", {"n": 2})
    assert b["sequence_in_segment"] == 1
    assert b["previous_event_hash"] == a["record_hash"]
    assert s2.verify() == (True, "ok")


def test_reopen_broken_chain_fail_closed(tmp_path):
    s = store(tmp_path)
    s.emit("WATCHER_WAKE", {"n": 1})
    seg = tmp_path / "obs" / "seg-000001.jsonl"
    seg.write_text(seg.read_text().replace('"n": 1', '"n": 7'),
                   encoding="utf-8")
    with pytest.raises(EmitError):
        store(tmp_path)  # 壊れた帳簿には追記させない


def test_append_only_prior_bytes_untouched(tmp_path):
    s = store(tmp_path)
    s.emit("WATCHER_WAKE", {"n": 1})
    seg = tmp_path / "obs" / "seg-000001.jsonl"
    before = seg.read_bytes()
    s.emit("WATCHER_WAKE", {"n": 2})
    after = seg.read_bytes()
    assert after.startswith(before)  # 既存バイトは不変(純 append)
    assert len(after.splitlines()) == 2
