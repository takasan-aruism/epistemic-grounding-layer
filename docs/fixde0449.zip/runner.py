#!/usr/bin/env python3
"""workcell runner v0.1.1 — GPT監査 S-1..S-8 対応版 + DE-0449 修正。

v0.1.1 (DE-0449 由来、Claude web 起票):
- call_vllm が message.content の型を検査。None/空は EmptyModelResponse。
  → terminal にせず反復を消費してフィードバック(reasoning で max_tokens
    到達した場合に run 全体を潰さないため)。恒久的に空なら BUDGET_EXHAUSTED。
- max_tokens を packet から可変化(既定 16384)。
- model_fn 注入経路で非文字列応答が来た場合も MODEL_PROTOCOL_ERROR。

v0 からの構造変更(GPT 監査裁定):
S-1  implementation_files / immutable_test_files を分離。テストは packet 側
     資材(workspace 外)から毎反復コピーし、テスト実行後に sha 照合。
     変化 = TEST_TAMPERED で即時終了。モデルがテストパスへ書こうとしたら
     REJECTED_SCOPE_VIOLATION。
S-2  sandbox 前提検査: WORKCELL_SANDBOXED=1(systemd ユニットが付与)が
     無ければ起動拒否(--unsafe-dev で明示バイパス、ログに残る)。
     ※ runner は sandbox の「存在検査」までしか出来ない。防止は OS 層。
S-3  毎 run 新規 workspace(run_id 配下)。既存・非空は WORKSPACE_CONTAMINATED。
S-4  テスト前後 + 終了時に disk から再読込した sha を記録。
     テスト中の実装自己変更 = IMPL_MODIFIED_DURING_TEST。
S-5  run log は workspace 外(run_dir 直下)。run_id / seq / prev_hash /
     record_hash の hash chain。runner_sha256 / packet_sha256 を先頭記録。
     ※ chain は改竄の「検出」であり「防止」ではない(同一 UID なら書ける)。
S-6  厳格 parse: file block 外の残余テキスト・重複 path・必須ファイル未提出は
     FORMAT/INCOMPLETE 違反として反復消費(フィードバック)。
S-7  全例外を terminal status へ変換し、必ず RESULT_PACKET を書く。
     (KeyboardInterrupt / SIGKILL までは保証しない)
S-8  攻撃テストを test_runner.py に追加。

claim ceiling(GPT 裁定採用):
  DETERMINISTIC_GENERATE_WRITE_TEST_RETRY_LOOP_DEMONSTRATED_ON_UNIT_FIXTURES
禁止: DRIFT_STRUCTURALLY_IMPOSSIBLE / FIXED_TESTS_ENFORCED(OS層なしでは
  「改変検出付き」まで)/ ALLOWED_FILES_ONLY_WRITABLE /
  APPEND_ONLY_RUN_LOG_PROVEN / QWEN_IMPLEMENTATION_PATH_READY
"""
from __future__ import annotations

import argparse
import hashlib
import json
import os
import re
import secrets
import shutil
import subprocess
import sys
import time
import urllib.error
import urllib.request
from pathlib import Path

FILE_BLOCK = re.compile(
    r"<file\s+path=\"(?P<path>[^\"]+)\">\n(?P<body>.*?)\n</file>", re.DOTALL
)

SYSTEM_PROMPT = """あなたは実装 worker である。以下を厳守せよ。
1. 出力は <file path="相対パス">…</file> ブロックのみ。ブロック外に一切の文字を出力しない。
2. implementation_files に列挙されたパスのみ出力できる。テストファイルは出力禁止。
3. spec の合格条件(同梱テスト)を満たす完全なファイル内容を出力する。全文であること。
4. spec にない機能を追加しない。
5. テスト結果について何も主張しない(結果は runner が実測する)。"""

TERMINAL = {"PASSED", "BUDGET_EXHAUSTED", "REJECTED_SCOPE_VIOLATION",
            "TEST_TAMPERED", "IMPL_MODIFIED_DURING_TEST", "PACKET_INVALID",
            "WORKSPACE_CONTAMINATED", "MODEL_TIMEOUT", "MODEL_PROTOCOL_ERROR",
            "TEST_TIMEOUT", "TEST_EXEC_ERROR", "SANDBOX_NOT_VERIFIED",
            "INTERNAL_RUNNER_ERROR"}

REQUIRED_KEYS = {"task_id", "spec_file", "implementation_files",
                 "immutable_test_files", "test_cmd", "max_iterations"}


def sha256b(data: bytes) -> str:
    return hashlib.sha256(data).hexdigest()


def sha256f(path: Path) -> str:
    return sha256b(path.read_bytes())


def confined(root: Path, rel: str) -> Path:
    p = (root / rel).resolve()
    if not str(p).startswith(str(root.resolve()) + os.sep):
        raise ValueError(f"path escape rejected: {rel}")
    return p


class ChainLog:
    """workspace 外・hash chain 付き run log。改竄の検出用(防止ではない)。"""

    def __init__(self, path: Path, run_id: str):
        self.path, self.run_id = path, run_id
        self.seq, self.prev = 0, "0" * 64

    def append(self, kind: str, **fields):
        rec = {"run_id": self.run_id, "seq": self.seq,
               "ts": time.strftime("%Y-%m-%dT%H:%M:%SZ", time.gmtime()),
               "kind": kind, "prev_hash": self.prev, **fields}
        rec["record_hash"] = sha256b(
            json.dumps(rec, sort_keys=True, ensure_ascii=False).encode())
        with open(self.path, "a", encoding="utf-8") as f:
            f.write(json.dumps(rec, ensure_ascii=False) + "\n")
        self.seq += 1
        self.prev = rec["record_hash"]
        return rec


def verify_chain(path: Path) -> tuple[bool, str]:
    prev, seq = "0" * 64, 0
    for i, line in enumerate(path.read_text(encoding="utf-8").splitlines()):
        rec = json.loads(line)
        claimed = rec.pop("record_hash")
        if rec.get("prev_hash") != prev:
            return False, f"line {i}: prev_hash mismatch"
        if rec.get("seq") != seq:
            return False, f"line {i}: seq mismatch"
        if sha256b(json.dumps(rec, sort_keys=True,
                              ensure_ascii=False).encode()) != claimed:
            return False, f"line {i}: record_hash mismatch"
        prev, seq = claimed, seq + 1
    return True, "ok"


class EmptyModelResponse(Exception):
    """HTTP/JSON の形は正しいが本文が空(reasoning で max_tokens 到達等)。
    プロトコル異常ではないので terminal にせず、反復を消費して再試行する。"""

    def __init__(self, finish_reason: str, note: str = ""):
        super().__init__(f"empty content (finish_reason={finish_reason}) {note}".strip())
        self.finish_reason = finish_reason


def call_vllm(endpoint: str, model: str, messages: list[dict],
              timeout: int = 600, max_tokens: int = 16384) -> str:
    body = json.dumps({"model": model, "messages": messages,
                       "temperature": 0.2, "max_tokens": max_tokens}).encode()
    req = urllib.request.Request(endpoint, data=body,
                                 headers={"Content-Type": "application/json"})
    with urllib.request.urlopen(req, timeout=timeout) as resp:
        data = json.loads(resp.read())
    choice = data["choices"][0]          # 形が違えば例外 → MODEL_PROTOCOL_ERROR
    content = choice["message"].get("content")
    if not isinstance(content, str) or not content.strip():
        note = ""
        if choice["message"].get("reasoning_content"):
            note = "(reasoning_content present: budget likely exhausted before output)"
        raise EmptyModelResponse(str(choice.get("finish_reason")), note)
    return content


def parse_strict(text: str, impl_allowed: set[str]) -> dict[str, str]:
    """厳格 parse。戻り: files。例外:
    PermissionError = スコープ違反(terminal相当) / ValueError = 形式違反(反復消費)"""
    out: dict[str, str] = {}
    spans = []
    for m in FILE_BLOCK.finditer(text):
        path, body = m.group("path"), m.group("body")
        spans.append(m.span())
        if path not in impl_allowed:
            raise PermissionError(f"disallowed path: {path}")
        if path in out:
            raise ValueError(f"duplicate file block: {path}")
        out[path] = body
    residue = text
    for a, b in reversed(spans):
        residue = residue[:a] + residue[b:]
    if residue.strip():
        raise ValueError(f"prose outside file blocks: {residue.strip()[:80]!r}")
    if not out:
        raise ValueError("no file blocks in reply")
    return out


def sandbox_check(unsafe_dev: bool) -> tuple[bool, str]:
    if os.environ.get("WORKCELL_SANDBOXED") == "1":
        return True, "env WORKCELL_SANDBOXED=1"
    if unsafe_dev:
        return True, "SANDBOX_BYPASSED (--unsafe-dev)"
    return False, "sandbox marker absent; refuse to start"


def run_packet(packet: dict, runs_root: Path, model_fn=None,
               unsafe_dev: bool = False, run_id: str | None = None) -> dict:
    run_id = run_id or time.strftime("%Y%m%dT%H%M%SZ-",
                                     time.gmtime()) + secrets.token_hex(4)
    run_dir = runs_root / run_id
    run_dir.mkdir(parents=True, exist_ok=True)
    log = ChainLog(run_dir / "run_log.jsonl", run_id)
    result: dict = {"task_id": packet.get("task_id", "?"), "run_id": run_id,
                    "status": "INTERNAL_RUNNER_ERROR", "iterations_used": 0,
                    "files": [], "needs_human": True,
                    "run_log": str(run_dir / "run_log.jsonl")}

    def finish(status: str, **extra) -> dict:
        result.update(status=status, needs_human=(status != "PASSED"), **extra)
        log.append("RESULT_PACKET", **{k: v for k, v in result.items()
                                       if k != "run_log"})
        (run_dir / "RESULT_PACKET.json").write_text(
            json.dumps(result, ensure_ascii=False, indent=2), encoding="utf-8")
        return result

    try:
        ok, why = sandbox_check(unsafe_dev)
        log.append("SANDBOX_CHECK", ok=ok, detail=why, uid=os.getuid())
        if not ok:
            return finish("SANDBOX_NOT_VERIFIED", detail=why)

        missing = REQUIRED_KEYS - set(packet)
        if missing:
            return finish("PACKET_INVALID", detail=f"missing keys: {sorted(missing)}")
        impl_files = list(packet["implementation_files"])
        test_files = {rel: Path(src) for rel, src in
                      packet["immutable_test_files"].items()}
        overlap = set(impl_files) & set(test_files)
        if overlap:
            return finish("PACKET_INVALID", detail=f"impl/test overlap: {sorted(overlap)}")
        try:
            spec = Path(packet["spec_file"]).read_text(encoding="utf-8")
            test_manifest = {rel: sha256f(src) for rel, src in test_files.items()}
        except OSError as e:
            return finish("PACKET_INVALID", detail=f"unreadable input: {e}")

        workspace = run_dir / "ws"
        if workspace.exists() and any(workspace.iterdir()):
            return finish("WORKSPACE_CONTAMINATED", detail=str(workspace))
        workspace.mkdir(exist_ok=True)

        log.append("PACKET_START", task_id=packet["task_id"],
                   packet_sha256=sha256b(json.dumps(
                       packet, sort_keys=True, ensure_ascii=False).encode()),
                   runner_sha256=sha256f(Path(__file__)),
                   spec_sha256=sha256b(spec.encode()),
                   implementation_files=impl_files,
                   immutable_test_manifest=test_manifest,
                   max_iterations=int(packet["max_iterations"]))

        files: dict[str, str] = {}
        last_test: str | None = None
        test_timeout = int(packet.get("test_timeout_s", 300))

        for it in range(1, int(packet["max_iterations"]) + 1):
            result["iterations_used"] = it
            parts = [f"# SPEC\n{spec}",
                     f"# implementation_files\n{json.dumps(impl_files)}"]
            if files:
                parts.append("# 現在の実装ファイル\n" + "\n".join(
                    f'<file path="{p}">\n{c}\n</file>' for p, c in files.items()))
            if last_test is not None:
                parts.append(f"# 直前のフィードバック(修正せよ)\n{last_test}")
            user = "\n\n".join(parts)
            messages = [{"role": "system", "content": SYSTEM_PROMPT},
                        {"role": "user", "content": user}]
            try:
                reply = (model_fn(messages) if model_fn is not None else
                         call_vllm(packet["endpoint"], packet["model"], messages,
                                   max_tokens=int(packet.get("max_tokens", 16384))))
            except EmptyModelResponse as e:
                # 形は正しいが本文が空。terminal にせず反復を消費して促す。
                log.append("EMPTY_RESPONSE", iteration=it, detail=str(e),
                           finish_reason=e.finish_reason)
                last_test = ("(応答本文が空だった。思考を短く切り上げ、"
                             "<file>ブロックのみを直ちに出力せよ)")
                continue
            except (TimeoutError, urllib.error.URLError) as e:
                log.append("MODEL_ERROR", iteration=it, detail=str(e))
                return finish("MODEL_TIMEOUT", detail=str(e))
            except Exception as e:
                log.append("MODEL_ERROR", iteration=it, detail=str(e))
                return finish("MODEL_PROTOCOL_ERROR", detail=str(e))
            if not isinstance(reply, str):   # model_fn 注入経路の防御
                log.append("MODEL_ERROR", iteration=it, detail="non-str reply")
                return finish("MODEL_PROTOCOL_ERROR", detail="non-str reply")
            log.append("MODEL_REPLY", iteration=it,
                       prompt_sha256=sha256b(user.encode()),
                       reply_sha256=sha256b(reply.encode()), reply=reply)

            try:
                new_files = parse_strict(reply, set(impl_files))
            except PermissionError as e:
                log.append("SCOPE_VIOLATION", iteration=it, detail=str(e))
                return finish("REJECTED_SCOPE_VIOLATION", detail=str(e))
            except ValueError as e:
                log.append("FORMAT_VIOLATION", iteration=it, detail=str(e))
                last_test = f"(形式違反: {e}。<file>ブロックのみで再出力せよ)"
                continue

            files.update(new_files)
            for rel, content in new_files.items():
                p = confined(workspace, rel)
                p.parent.mkdir(parents=True, exist_ok=True)
                p.write_text(content, encoding="utf-8")
                log.append("FILE_WRITTEN", iteration=it, path=rel,
                           sha256=sha256b(content.encode()))
            absent = [p for p in impl_files if not (workspace / p).exists()]
            if absent:
                log.append("INCOMPLETE_SUBMISSION", iteration=it, missing=absent)
                last_test = f"(未提出の必須ファイル: {absent}。全て出力せよ)"
                continue

            # 採点表を毎回、部屋の外の原本から敷き直す
            for rel, src in test_files.items():
                dst = confined(workspace, rel)
                dst.parent.mkdir(parents=True, exist_ok=True)
                shutil.copyfile(src, dst)
            pre = {p: sha256f(workspace / p) for p in
                   list(impl_files) + list(test_files)}
            log.append("PRE_TEST_SNAPSHOT", iteration=it, sha256=pre)

            for pyc in workspace.rglob("__pycache__"):
                shutil.rmtree(pyc, ignore_errors=True)
            env = dict(os.environ, PYTHONDONTWRITEBYTECODE="1")
            try:
                proc = subprocess.run(packet["test_cmd"], cwd=workspace,
                                      capture_output=True, text=True,
                                      timeout=test_timeout, env=env)
            except subprocess.TimeoutExpired:
                log.append("TEST_ERROR", iteration=it, detail="timeout")
                return finish("TEST_TIMEOUT", detail=f">{test_timeout}s")
            except OSError as e:
                log.append("TEST_ERROR", iteration=it, detail=str(e))
                return finish("TEST_EXEC_ERROR", detail=str(e))
            tail = (proc.stdout + proc.stderr)[-4000:]

            post = {p: sha256f(workspace / p) if (workspace / p).exists()
                    else "DELETED" for p in pre}
            log.append("TEST_RUN", iteration=it, exit_code=proc.returncode,
                       output_tail=tail, post_sha256=post)
            tampered = [p for p in test_files if post[p] != pre[p]]
            if tampered:
                return finish("TEST_TAMPERED", detail=f"tests changed: {tampered}")
            self_mod = [p for p in impl_files if post[p] != pre[p]]
            if self_mod:
                return finish("IMPL_MODIFIED_DURING_TEST",
                              detail=f"impl changed during test: {self_mod}")

            if proc.returncode == 0:
                final = [{"path": p, "final_disk_sha256": sha256f(workspace / p),
                          "model_reply_sha256": sha256b(files[p].encode())}
                         for p in sorted(impl_files)]
                return finish("PASSED", files=final)
            last_test = tail

        return finish("BUDGET_EXHAUSTED")
    except Exception as e:  # S-7 catch-all
        try:
            log.append("INTERNAL_ERROR", detail=repr(e))
        except Exception:
            pass
        return finish("INTERNAL_RUNNER_ERROR", detail=repr(e))


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("packet")
    ap.add_argument("--runs-root", required=True)
    ap.add_argument("--unsafe-dev", action="store_true")
    a = ap.parse_args()
    packet = json.loads(Path(a.packet).read_text(encoding="utf-8"))
    r = run_packet(packet, Path(a.runs_root), unsafe_dev=a.unsafe_dev)
    print(json.dumps(r, ensure_ascii=False, indent=2))
    sys.exit(0 if r["status"] == "PASSED" else 1)


if __name__ == "__main__":
    main()
