# FIX-DE0449 — S0 失敗の原因裁定と修正物(Claude web → Claude Code)

## 裁定: 選択肢 C(spec 欠陥の監査)が正解。欠陥は 2 件、どちらも Claude(web) 側。

Claude Code の停止判断・A/B/C 提示は妥当。A(再実行)を選ばなかったのは正しい。
同じ packet を再投入しても収束しない、という読みは当たっている。

### 欠陥1(本命・発注側): S0.md の chain 検証仕様に起点が書かれていなかった

iter1/iter2 が同一 assert(`chain_ok is True`)で落ちた原因。
spec は「prev_hash の連結・seq 連番」とだけ書き、**先頭行の期待値**
(prev_hash = "0"*64、seq = 0)を明記していなかった。
runner は immutable tests を実装者に見せないため、Qwen は初期値を推測できない。
= Qwen の能力問題ではなく発注書の欠陥。M1.md には書いてあり、S0.md で落とした。

修正: S0.md の chain 検証節に擬似コードで検証規則を明記(genesis / seq 初期値 /
body の作り方 / json.dumps の区切り既定 / 空行の扱い)。
修正版 spec のとおりに実装すれば、テスト fixture に対して
clean=(True,"ok") / tampered=(False,"line 1: hash") となることを実測済み。

### 欠陥2(runner・D-1): content=None で run 全体が crash

`call_vllm` が `message.content` を無検査で返し、`sha256b(reply.encode())` で
AttributeError → INTERNAL_RUNNER_ERROR。報告どおり。

修正(runner v0.1.1):
- `content` が str でない/空なら `EmptyModelResponse` を送出。
  **terminal にしない**。EMPTY_RESPONSE を記録し、反復を消費して
  「思考を短く切り上げ <file> ブロックのみ出力せよ」とフィードバックして継続。
  恒久的に空なら BUDGET_EXHAUSTED(fail-closed は維持)。
- `max_tokens` を packet から可変化(既定 16384)。
  iter3 の空応答は reasoning が予算を食い切った可能性が高いため。
- model_fn 経路で非文字列が来た場合も MODEL_PROTOCOL_ERROR。
- 追加テスト 3 件。自己テスト **21/21 PASS**(従来 18 + 新規 3)。

## 差し替えファイルと sha256(C-4 再pin 対象)

```
runner.py       b617e65ef4151a5b386eb03f285d69de654ab3acf3e85ab12d055ad7e7b64ad2
test_runner.py  e7e12844f00cbe2edc26c3297fc21ce7a287620a88949da12fc70cb89e123126
S0.md           714381c6d2be5fd6ad3c72568621cc9a26e10d3587af995d379c0efea468a80b
```

- test_status_views.py / packet(JOB01.json)は **変更なし**(既存のまま)。
- glue 3本・setup は変更なし。

## Claude Code への手順

```
1. 上記 3 ファイルを差し替え配置し、sha256 を照合して報告。
   旧 pin(runner c86ba8bf / S0.md f67618e5)は void。新 sha を C-4 pin。
2. runner 自己テストを実行: python3 -m pytest test_runner.py -q → 21/21 を実測。
   ※ この pytest は takasan 権限で実行(従来どおり)。
3. sudo systemctl start workcell-runner@JOB01 で S0 を再実行。
4. RESULT_PACKET / run_log を報告。
   - PASSED → C-4(status 系へ配備、UI が実データを表示することを確認)
   - 失敗 → 実装せず(D-2)差し戻し。run_log の Qwen 応答を添えること。
5. 帳簿記録: DE-0449 の後続として、原因2件(spec 欠陥 / runner 欠陥)と
   修正・再pin・再実行結果を記録。
```

## 記録すべき知見(DE 候補)

**SPEC_INITIAL_STATE_OMISSION**: 実装者はテストを見られないため、
検証アルゴリズムの**初期値・境界条件**を spec に明記しない限り推測不能である。
「連番」「連結」と書くだけでは起点が伝わらない。
今回、発注側欠陥と受注側欠陥を run_log から分離できた最初の実例
(2反復とも同一 assert = 仕様不足の兆候、モデル能力不足ではない)。
