"""runner v0.1 受け入れ + 攻撃テスト(GPT 監査 S-8 対応)。"""
import json
from pathlib import Path

import pytest

from runner import run_packet, verify_chain, parse_strict

GOOD_IMPL = '<file path="mod.py">\ndef add(a, b):\n    return a + b\n</file>'
BAD_IMPL = GOOD_IMPL.replace("a + b", "a - b")
TEST_BODY = "from mod import add\nassert add(1, 2) == 3\nprint('ok')\n"


def make(tmp: Path, test_body=TEST_BODY, max_it=4, **over):
    spec = tmp / "spec.md"
    spec.write_text("add(a,b) は a+b。テストは runner が供給する。", encoding="utf-8")
    tdir = tmp / "immutable_tests"
    tdir.mkdir(exist_ok=True)
    (tdir / "check.py").write_text(test_body, encoding="utf-8")
    pkt = {"task_id": "T", "spec_file": str(spec),
           "implementation_files": ["mod.py"],
           "immutable_test_files": {"check.py": str(tdir / "check.py")},
           "test_cmd": ["python3", "check.py"], "max_iterations": max_it,
           "test_timeout_s": 5}
    pkt.update(over)
    return pkt


def run(tmp, pkt, fn, **kw):
    return run_packet(pkt, tmp / "runs", model_fn=fn, unsafe_dev=True, **kw)


# --- 基本経路 ---

def test_happy_path_and_chain(tmp_path):
    r = run(tmp_path, make(tmp_path), lambda m: GOOD_IMPL)
    assert r["status"] == "PASSED" and r["iterations_used"] == 1
    ok, why = verify_chain(Path(r["run_log"]))
    assert ok, why
    f = r["files"][0]
    assert f["final_disk_sha256"] == f["model_reply_sha256"]


def test_iterative_fix(tmp_path):
    replies = iter([BAD_IMPL, GOOD_IMPL])
    r = run(tmp_path, make(tmp_path), lambda m: next(replies))
    assert r["status"] == "PASSED" and r["iterations_used"] == 2


def test_budget_exhausted(tmp_path):
    r = run(tmp_path, make(tmp_path, max_it=2), lambda m: BAD_IMPL)
    assert r["status"] == "BUDGET_EXHAUSTED" and r["needs_human"]


# --- S-1: テスト固定 ---

def test_model_cannot_write_tests(tmp_path):
    evil = GOOD_IMPL + '\n<file path="check.py">\nprint("ok")\n</file>'
    r = run(tmp_path, make(tmp_path), lambda m: evil)
    assert r["status"] == "REJECTED_SCOPE_VIOLATION"


def test_tampered_tests_detected(tmp_path):
    # 採点表自身を書き換えて exit 0 する「合格」— rc==0 でも改竄検出で失格
    evil_test = ("open('check.py','w').write('gutted')\nprint('ok')\n")
    r = run(tmp_path, make(tmp_path, test_body=evil_test), lambda m: GOOD_IMPL)
    assert r["status"] == "TEST_TAMPERED"


def test_impl_self_modification_detected(tmp_path):
    # import 時に自分自身を書き換える実装 — テスト合格でも失格
    tricky = ('<file path="mod.py">\n'
              "open('mod.py','a').write('# mutated')\n"
              "def add(a, b):\n    return a + b\n</file>")
    r = run(tmp_path, make(tmp_path), lambda m: tricky)
    assert r["status"] == "IMPL_MODIFIED_DURING_TEST"


# --- S-3: workspace 汚染 ---

def test_contaminated_workspace_refused(tmp_path):
    runs = tmp_path / "runs"
    (runs / "fixed" / "ws").mkdir(parents=True)
    (runs / "fixed" / "ws" / "leftover.py").write_text("x")
    r = run_packet(make(tmp_path), runs, model_fn=lambda m: GOOD_IMPL,
                   unsafe_dev=True, run_id="fixed")
    assert r["status"] == "WORKSPACE_CONTAMINATED"


# --- S-5: ログ改竄検出 ---

def test_chain_detects_tampering(tmp_path):
    r = run(tmp_path, make(tmp_path), lambda m: GOOD_IMPL)
    p = Path(r["run_log"])
    lines = p.read_text().splitlines()
    rec = json.loads(lines[2])
    rec["kind"] = "FORGED"
    lines[2] = json.dumps(rec, ensure_ascii=False)
    p.write_text("\n".join(lines) + "\n")
    ok, why = verify_chain(p)
    assert not ok


# --- S-6: 厳格 parse ---

def test_prose_residue_rejected(tmp_path):
    r = run(tmp_path, make(tmp_path, max_it=1),
            lambda m: BAD_IMPL + "\n全テスト合格しました。")
    assert r["status"] == "BUDGET_EXHAUSTED"
    log = Path(r["run_log"]).read_text()
    assert "FORMAT_VIOLATION" in log and "prose outside" in log
    assert "TEST_RUN" not in log  # 書込みもテストも起きていない


def test_duplicate_block_rejected(tmp_path):
    dup = GOOD_IMPL + "\n" + GOOD_IMPL
    r = run(tmp_path, make(tmp_path, max_it=1), lambda m: dup)
    assert "duplicate" in Path(r["run_log"]).read_text()


def test_missing_required_file_feedback(tmp_path):
    pkt = make(tmp_path, max_it=1)
    pkt["implementation_files"] = ["mod.py", "util.py"]
    r = run(tmp_path, pkt, lambda m: GOOD_IMPL)  # util.py 未提出
    assert "INCOMPLETE_SUBMISSION" in Path(r["run_log"]).read_text()


# --- S-7: fail-closed terminal ---

def test_model_timeout_terminal(tmp_path):
    def boom(m):
        raise TimeoutError("vllm dead")
    r = run(tmp_path, make(tmp_path), boom)
    assert r["status"] == "MODEL_TIMEOUT"
    assert (Path(r["run_log"]).parent / "RESULT_PACKET.json").exists()


def test_malformed_model_response_terminal(tmp_path):
    def boom(m):
        raise KeyError("choices")
    r = run(tmp_path, make(tmp_path), boom)
    assert r["status"] == "MODEL_PROTOCOL_ERROR"


def test_test_timeout_terminal(tmp_path):
    sleepy = "import time\ntime.sleep(60)\n"
    r = run(tmp_path, make(tmp_path, test_body=sleepy, max_it=1),
            lambda m: GOOD_IMPL)
    assert r["status"] == "TEST_TIMEOUT"


def test_packet_invalid_terminal(tmp_path):
    r = run(tmp_path, {"task_id": "broken"}, lambda m: GOOD_IMPL)
    assert r["status"] == "PACKET_INVALID"


def test_impl_test_overlap_invalid(tmp_path):
    pkt = make(tmp_path)
    pkt["implementation_files"] = ["mod.py", "check.py"]
    r = run(tmp_path, pkt, lambda m: GOOD_IMPL)
    assert r["status"] == "PACKET_INVALID"


# --- S-2: sandbox 前提 ---

def test_sandbox_refusal_without_marker(tmp_path, monkeypatch):
    monkeypatch.delenv("WORKCELL_SANDBOXED", raising=False)
    r = run_packet(make(tmp_path), tmp_path / "runs",
                   model_fn=lambda m: GOOD_IMPL, unsafe_dev=False)
    assert r["status"] == "SANDBOX_NOT_VERIFIED"


def test_path_escape_in_reply(tmp_path):
    evil = '<file path="../outside.py">\nx = 1\n</file>'
    r = run(tmp_path, make(tmp_path), lambda m: evil)
    assert r["status"] == "REJECTED_SCOPE_VIOLATION"
    assert not (tmp_path / "runs").parent.joinpath("outside.py").exists()


# --- v0.1.1: 空応答 / 非文字列応答の扱い(DE-0449 由来) ---

def test_empty_model_response_consumes_iteration_not_terminal(tmp_path):
    """content=None 相当。terminal にせず反復を消費し、次で回復できること。"""
    from runner import EmptyModelResponse
    calls = []

    def fn(m):
        calls.append(1)
        if len(calls) == 1:
            raise EmptyModelResponse("length", "(reasoning_content present)")
        return GOOD_IMPL

    r = run(tmp_path, make(tmp_path, max_it=3), fn)
    assert r["status"] == "PASSED"
    assert r["iterations_used"] == 2
    log = Path(r["run_log"]).read_text()
    assert "EMPTY_RESPONSE" in log and "length" in log


def test_persistent_empty_response_ends_budget_exhausted(tmp_path):
    from runner import EmptyModelResponse

    def fn(m):
        raise EmptyModelResponse("length")

    r = run(tmp_path, make(tmp_path, max_it=2), fn)
    assert r["status"] == "BUDGET_EXHAUSTED" and r["needs_human"] is True
    assert (Path(r["run_log"]).parent / "RESULT_PACKET.json").exists()


def test_non_string_reply_is_protocol_error(tmp_path):
    r = run(tmp_path, make(tmp_path), lambda m: None)
    assert r["status"] == "MODEL_PROTOCOL_ERROR"
