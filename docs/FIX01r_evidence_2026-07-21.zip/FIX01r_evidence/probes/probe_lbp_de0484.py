import bridge_reconciler as rc

REAL = '/tmp/repoA'
def proof(repo_identity=None, repo_realpath=None, head='H1'):
    p = {'balanced': True, 'baseline': False, 'head': head,
         'orphans_event_without_git': [], 'orphans_git_without_event': [],
         'checked_files': [], 'applies_seen': 0}
    if repo_identity is not None: p['repo_identity'] = repo_identity
    if repo_realpath is not None: p['repo_realpath'] = repo_realpath
    return {'kind': 'RECONCILIATION_BALANCED', 'payload': p}

print('--- 事例1: 自 repo の有効 proof の後に「旧形式(repo場なし)proof」が来る')
log = [proof('rri', REAL), proof()]          # 2件目は legacy
pr, fresh = rc.latest_balance_proof(log, 'rri', REAL)
print('  返った proof の payload repo_identity =', pr['payload'].get('repo_identity'))
print('  fresh =', fresh)
print('  仕様: legacy proof は「対象外=この関数を通らない」→ 1件目(rri)が返るべき')
print('  実装: %s' % ('仕様どおり' if pr['payload'].get('repo_identity') == 'rri' else '★非適合: legacy proof を返した'))

print()
print('--- 事例2: 自 repo の有効 proof の後に「他 repo の proof」が来る')
log = [proof('rri', REAL), proof('egl', '/tmp/repoB')]
pr, fresh = rc.latest_balance_proof(log, 'rri', REAL)
print('  返った proof の payload repo_identity =', pr['payload'].get('repo_identity'))
print('  仕様: 対象 repo の proof のみ走査 → rri が返るべき')
print('  実装: %s' % ('仕様どおり' if pr['payload'].get('repo_identity') == 'rri' else '★非適合: 他 repo の proof を返した'))

print()
print('--- 事例3: 他 repo の IMBALANCED proof が最後に来る')
bad = {'kind': 'RECONCILIATION_IMBALANCED', 'payload': {'repo_identity': 'egl', 'repo_realpath': '/tmp/repoB'}}
log = [proof('rri', REAL), bad]
pr, fresh = rc.latest_balance_proof(log, 'rri', REAL)
print('  fresh =', fresh, '/ 返った kind =', pr['kind'])
print('  仕様: 他 repo の proof は走査対象外 → rri の BALANCED が返り fresh=True であるべき')
print('  実装: %s' % ('仕様どおり' if fresh and pr['kind'] == 'RECONCILIATION_BALANCED' else '★非適合: 他 repo の不均衡で自 repo の mint が阻害される'))
