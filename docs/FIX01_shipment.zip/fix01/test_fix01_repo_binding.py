"""FIX-01 immutable tests — repo identity binding (T-1/T-2/T-3/T-6 + positive controls).
SEAL-2026-07-21 §4 / bundle-a-remediation-spec-v1.1 R1. DO NOT MODIFY (contract).
Requires: git available in sandbox (V-item: Claude Code confirms before staging).
"""
import os, subprocess, hashlib, tempfile, shutil
import pytest

import patch_bridge as pb
import bridge_reconciler as rc
import bridge_minter as bm


def _sha(b): return hashlib.sha256(b).hexdigest()

def _git(d, *a):
    r = subprocess.run(['git', '-C', d, *a], capture_output=True, text=True)
    assert r.returncode == 0, r.stderr
    return r.stdout

def make_repo(tmp, name, content=b'original\n'):
    d = os.path.join(tmp, name); os.makedirs(d)
    subprocess.run(['git', 'init', '-q', d], check=True)
    _git(d, 'config', 'user.email', 't@t'); _git(d, 'config', 'user.name', 't')
    with open(os.path.join(d, 'impl.py'), 'wb') as f: f.write(content)
    _git(d, 'add', '.'); _git(d, 'commit', '-q', '-m', 'init')
    return d

def pa_event(repo_identity, repo_realpath, filenames, fingerprint, token_id='TOK-X',
             outcome='APPLIED', base_commit='deadbeef'):
    p = {'outcome': outcome, 'fingerprint': fingerprint, 'base_commit': base_commit,
         'filenames': filenames, 'token_id': token_id}
    if repo_identity is not None: p['repo_identity'] = repo_identity
    if repo_realpath is not None: p['repo_realpath'] = repo_realpath
    return {'kind': 'PATCH_APPLICATION', 'payload': p}


@pytest.fixture()
def tmp(request):
    d = tempfile.mkdtemp(prefix='fix01_')
    request.addfinalizer(lambda: shutil.rmtree(d, ignore_errors=True))
    return d


# ---- emit path (patch_bridge) -------------------------------------------------
def _mk_valid():
    """Build a _ValidatedPatch through the module's own public validator (real API)."""
    art = {'diff': 'a/impl.py b/impl.py', 'base_commit': 'abc', 'fingerprint': 'hash'}
    return pb.validate_artifact(art, ['impl.py'])

def test_emit_requires_repo_identity(tmp):
    v = _mk_valid()
    rec = lambda task, kind, payload, ts, identity=None: {'ok': True}
    with pytest.raises(ValueError):
        pb.emit_patch_application(rec, 't', v, 'APPLIED', 'ts')            # both missing
    with pytest.raises(ValueError):
        pb.emit_patch_application(rec, 't', v, 'APPLIED', 'ts',
                                  repo_identity='rri')                     # realpath missing
    with pytest.raises(ValueError):
        pb.emit_patch_application(rec, 't', v, 'APPLIED', 'ts',
                                  repo_realpath='/x')                      # identity missing
    out = {}
    def rec2(task, kind, payload, ts, identity=None):
        out.update(payload); return {'ok': True}
    pb.emit_patch_application(rec2, 't', v, 'APPLIED', 'ts', token_id='TOK-9',
                              repo_identity='rri', repo_realpath='/home/x/rri')
    assert out['repo_identity'] == 'rri'
    assert out['repo_realpath'] == '/home/x/rri'
    assert out['token_id'] == 'TOK-9'            # existing keys unchanged
    assert out['outcome'] == 'APPLIED'

# ---- T-1 cross-repo contamination (reconciler level) --------------------------
def test_t1_cross_repo_contamination_detected(tmp):
    target = make_repo(tmp, 'target')
    dirty = b'unrecorded-change\n'
    with open(os.path.join(target, 'impl.py'), 'wb') as f: f.write(dirty)
    foreign = pa_event('FOREIGN', os.path.realpath(os.path.join(tmp, 'elsewhere')),
                       ['impl.py'], _sha(dirty))
    res = rc.reconcile(target, [foreign], 'target')
    assert not res.balanced                       # dirty file must NOT be covered by foreign PA
    assert 'impl.py' in res.orphans_git_without_event
    assert res.repo_identity == 'target'
    assert res.repo_realpath == os.path.realpath(target)

# positive control: same event bound to THIS repo does cover the file
def test_t1_positive_control_bound_event_covers(tmp):
    target = make_repo(tmp, 'target')
    dirty = b'recorded-change\n'
    with open(os.path.join(target, 'impl.py'), 'wb') as f: f.write(dirty)
    mine = pa_event('target', os.path.realpath(target), ['impl.py'], _sha(dirty))
    res = rc.reconcile(target, [mine], 'target')
    assert res.balanced

# ---- T-2 missing repo id excluded + counted -----------------------------------
def test_t2_unbound_event_excluded_and_counted(tmp):
    target = make_repo(tmp, 'target')
    dirty = b'x\n'
    with open(os.path.join(target, 'impl.py'), 'wb') as f: f.write(dirty)
    legacy = pa_event(None, None, ['impl.py'], _sha(dirty))     # no repo fields
    res = rc.reconcile(target, [legacy], 'target')
    assert not res.balanced                       # legacy event must not cover
    assert res.unbound_events_seen == 1

# ---- T-3 alias realpath -------------------------------------------------------
def test_t3_symlink_alias_rejected_for_other_repo(tmp):
    target = make_repo(tmp, 'target')
    other = make_repo(tmp, 'other')
    link = os.path.join(tmp, 'link_to_other'); os.symlink(other, link)
    dirty = b'y\n'
    with open(os.path.join(target, 'impl.py'), 'wb') as f: f.write(dirty)
    # event claims the symlink path (resolves to OTHER repo) -> must not cover target
    ev = pa_event('target', link, ['impl.py'], _sha(dirty))
    res = rc.reconcile(target, [ev], 'target')
    assert not res.balanced

def test_t3_symlink_alias_of_same_repo_accepted(tmp):
    target = make_repo(tmp, 'target')
    link = os.path.join(tmp, 'link_to_target'); os.symlink(target, link)
    dirty = b'z\n'
    with open(os.path.join(target, 'impl.py'), 'wb') as f: f.write(dirty)
    ev = pa_event('target', link, ['impl.py'], _sha(dirty))     # realpath(link)==realpath(target)
    res = rc.reconcile(target, [ev], 'target')
    assert res.balanced

# ---- proof binding + T-6 (minter level) ---------------------------------------
def _adjudication(repo, request):
    return {'kind': 'ENERGIZATION_ADJUDICATION', 'payload': {
        'adjudication_id': request['adjudication_id'],
        'authority_owner': 'TAKA', 'granted_by': 'TAKA', 'attribution': 'TAKA',
        'item_id': request['item_id'], 'repo_realpath': request['repo_realpath'],
        'base_commit': request['base_commit'], 'fingerprint': request['fingerprint'],
        'allowed_files': list(request['allowed_files']), 'expires_at': '9999-12-31T00:00:00Z'}}

def _proof(repo_identity, repo_realpath, head, balanced=True):
    return {'kind': 'RECONCILIATION_BALANCED' if balanced else 'RECONCILIATION_IMBALANCED',
            'payload': {'balanced': balanced, 'head': head,
                        'repo_identity': repo_identity, 'repo_realpath': repo_realpath,
                        'proof_issuance_identity': 'bridge-reconciler'}}

def _request(repo, ident='target'):
    head = _git(repo, 'rev-parse', 'HEAD').strip()
    return {'item_id': 'I1', 'task_id': 'T1', 'trace_id': 'TR1',
            'repo_identity': ident, 'repo_realpath': os.path.realpath(repo),
            'base_commit': head, 'allowed_files': ['impl.py'],
            'fingerprint': 'f' * 64, 'token_id': 'TOK-1', 'adjudication_id': 'ADJ-1'}

def test_t6_proof_repo_mismatch_refused(tmp):
    target = make_repo(tmp, 'target'); other = make_repo(tmp, 'other')
    req = _request(target)
    head = req['base_commit']
    log = [_adjudication(target, req),
           _proof('other', os.path.realpath(other), head)]   # proof for the WRONG repo
    with pytest.raises(bm.MintRefused):
        bm.mint_real_energize(req, log, target, now_ts='2026-07-21T00:00:00Z')

def test_t6b_legacy_proof_without_repo_fields_refused(tmp):
    target = make_repo(tmp, 'target')
    req = _request(target)
    log = [_adjudication(target, req),
           {'kind': 'RECONCILIATION_BALANCED',
            'payload': {'balanced': True, 'head': req['base_commit']}}]   # old-format proof
    with pytest.raises(bm.MintRefused):
        bm.mint_real_energize(req, log, target, now_ts='2026-07-21T00:00:00Z')

def test_t2b_unbound_pa_blocks_mint(tmp):
    target = make_repo(tmp, 'target')
    req = _request(target)
    log = [_adjudication(target, req),
           pa_event(None, None, ['impl.py'], 'a' * 64, token_id='TOK-OLD'),
           _proof('target', os.path.realpath(target), req['base_commit'])]
    with pytest.raises(bm.MintRefused):
        bm.mint_real_energize(req, log, target, now_ts='2026-07-21T00:00:00Z')

def test_mint_positive_control_clean_repo(tmp):
    target = make_repo(tmp, 'target')
    req = _request(target)
    log = [_adjudication(target, req),
           _proof('target', os.path.realpath(target), req['base_commit'])]
    tok = bm.mint_real_energize(req, log, target, now_ts='2026-07-21T00:00:00Z')
    assert tok.repo_identity == 'target'
    assert tok.token_id == 'TOK-1'
