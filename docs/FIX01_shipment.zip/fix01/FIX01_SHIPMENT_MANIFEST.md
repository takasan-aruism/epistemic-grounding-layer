# FIX-01 出荷マニフェスト(CONTENT_SEAL 付き)

authority: SEAL-2026-07-21 §4(FIX-LIFT-JREV0010。packet の CONTENT_SEAL 発行は
本捺印の範囲内につき Claude Web)。
date: 2026-07-21

## 同梱物
- FIX01_spec.md — 変更契約 + 現行3ソース逐語埋込(基点 sha: patch_bridge
  5ca50050 / bridge_reconciler 41c404ca / bridge_minter d77c5530)
- test_fix01_repo_binding.py — immutable tests(T-1/T-2/T-3/T-6 系 10本)
- FIX01.json — packet(パスは /srv/workcell 配置後に Claude Code が実パスへ
  合わせてよい。それ以外のフィールド変更は不可)

## 充足性検証(M1 前例)
使い捨て参照実装(Claude Web 作、検証後破棄・非出荷)に対し 10/10 passed を
実測済み。テストは充足可能である。

## 配備手順(Claude Code)
1. 同梱 sha256 を照合 → spec/tests を staging → packet 起動(JOB slot)。
2. Qwen 実装が immutable 10/10 に到達 → 3ファイルの適用後 sha を記帳。
3. 【注意】既存 oracle 群(verify_*/gate_*/jrev0010_attacks)は旧 API 呼出の
   ため、この時点では TypeError で壊れる(静かな誤動作ではない)。回帰実測は
   次便の FIX-01-OP(oracle 配管更新・置換ペア形式・assertion 不変)適用後に
   全件再実行する。それまで回帰 PASS を主張しない。
4. 事前条件の実測: sandbox 内で git が使用可能なこと(immutable tests が
   git init を要する)。不能なら STOP して報告(packet を回さない)。

## 予算の導出
3ファイル計 ≈31KB ≈ 8.5k tokens。E=8.5k, k=2, 2冪 → max_tokens 32768。
thinking 無効下では cutoff 拡大の既知害なし(DE-0467 系実測)。カットポイント
原則(容れ物でなく切断点)は維持。

## 変更しないこと
- immutable tests / spec の内容(sha 束縛)。
- FIX-02(apply 時再検査 + claim 原子化 + clock)/ FIX-03(CORRECTION)は
  FIX-01 終端後に順次(単一変数規律)。
