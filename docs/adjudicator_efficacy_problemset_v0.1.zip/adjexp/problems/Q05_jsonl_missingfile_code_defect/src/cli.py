import sys, os, json
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from analyzer import count_lines

def main(argv):
    if len(argv) != 2:
        print("ERROR: usage: cli.py <path>", file=sys.stderr)
        return 2
    path = argv[1]
    try:
        n = count_lines(path)
    except FileNotFoundError:
        print(json.dumps({"lines": 0}))
        return 0
    print(json.dumps({"lines": n}))
    return 0

if __name__ == "__main__":
    sys.exit(main(sys.argv))
