def count_lines(path):
    with open(path) as f:
        return sum(1 for _ in f)
