import sys, os, subprocess, json
root = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
cli = os.path.join(root, "src", "cli.py")
failures = []
def check(name, cond):
    if not cond:
        failures.append(name)

r = subprocess.run(["python3", cli, os.path.join(root, "fixtures", "sample.txt")],
                   capture_output=True, text=True)
check("normal_exit0", r.returncode == 0)
try:
    check("normal_linecount", json.loads(r.stdout)["lines"] == 4)
except Exception:
    check("normal_linecount", False)

m = subprocess.run(["python3", cli, os.path.join(root, "fixtures", "no_such_file.txt")],
                   capture_output=True, text=True)
check("missing_exit2", m.returncode == 2)
check("missing_error_on_stderr", "not found" in m.stderr)
check("missing_no_stdout", m.stdout.strip() == "")

if failures:
    print("FAIL: " + ",".join(failures))
    sys.exit(1)
print("PASS")
sys.exit(0)
