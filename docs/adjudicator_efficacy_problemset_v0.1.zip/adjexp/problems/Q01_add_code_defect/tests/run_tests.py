import sys, os
sys.path.insert(0, os.path.join(os.path.dirname(os.path.abspath(__file__)), "..", "src"))
from solution import add

failures = []
def check(name, cond):
    if not cond:
        failures.append(name)

check("add_basic", add(2, 3) == 5)
check("add_negative", add(-1, 1) == 0)

if failures:
    print("FAIL: " + ",".join(failures))
    sys.exit(1)
print("PASS")
sys.exit(0)
