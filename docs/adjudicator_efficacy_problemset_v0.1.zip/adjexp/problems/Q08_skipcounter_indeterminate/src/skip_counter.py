import sys, json

def main(argv):
    if len(argv) != 2:
        print("ERROR: usage: skip_counter.py <path>", file=sys.stderr)
        return 2
    try:
        with open(argv[1]) as f:
            lines = f.read().splitlines()
    except FileNotFoundError:
        print("ERROR: input file not found: " + argv[1], file=sys.stderr)
        return 2
    valid = 0
    errors = 0
    for raw in lines:
        try:
            obj = json.loads(raw)
            if not isinstance(obj, dict):
                raise ValueError("not an object")
            valid += 1
        except Exception:
            errors += 1
    print(json.dumps({"valid": valid, "errors": errors}))
    return 0

if __name__ == "__main__":
    sys.exit(main(sys.argv))
