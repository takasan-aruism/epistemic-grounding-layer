import sys, os, subprocess, json
root = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
cli = os.path.join(root, "src", "skip_counter.py")
failures = []
def check(name, cond):
    if not cond:
        failures.append(name)

r = subprocess.run(["python3", cli, os.path.join(root, "fixtures", "mixed.jsonl")],
                   capture_output=True, text=True)
check("exit0", r.returncode == 0)
parsed = None
try:
    parsed = json.loads(r.stdout)
    check("stdout_json", True)
except Exception:
    check("stdout_json", False)
if parsed is not None:
    check("valid_count", parsed.get("valid") == 5)
    check("errors_count", parsed.get("errors") == 2)
else:
    failures.extend(["valid_count", "errors_count"])
check("stderr_empty", r.stderr.strip() == "")

if failures:
    print("FAIL: " + ",".join(sorted(set(failures))))
    sys.exit(1)
print("PASS")
sys.exit(0)
