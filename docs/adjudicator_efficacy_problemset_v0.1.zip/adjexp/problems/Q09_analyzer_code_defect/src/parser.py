import json

def parse_lines(lines):
    valid = []
    malformed = []
    for i, raw in enumerate(lines, 1):
        try:
            obj = json.loads(raw)
            if not isinstance(obj, dict):
                raise ValueError("not an object")
            valid.append(obj)
        except (json.JSONDecodeError, ValueError):
            malformed.append(i)
    return valid, malformed
