def key_count(records, key):
    return sum(1 for r in records if key in r)

def _numeric_values(records, key):
    vals = []
    for r in records:
        v = r.get(key)
        if isinstance(v, (int, float)) and not isinstance(v, bool):
            vals.append(v)
    return vals

def average(records, key, total_lines=None):
    vals = _numeric_values(records, key)
    if not vals:
        return None
    return sum(vals) / total_lines
