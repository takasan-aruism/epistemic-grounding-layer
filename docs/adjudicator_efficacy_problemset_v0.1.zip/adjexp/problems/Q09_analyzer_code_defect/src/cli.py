import sys, os
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from parser import parse_lines
from stats import key_count, average
from report import render

def main(argv):
    if len(argv) != 3:
        print("ERROR: usage: cli.py <path> <key>", file=sys.stderr)
        return 2
    path, key = argv[1], argv[2]
    try:
        with open(path) as f:
            lines = f.read().splitlines()
    except FileNotFoundError:
        print("ERROR: input file not found: " + path, file=sys.stderr)
        return 2
    valid, malformed = parse_lines(lines)
    for ln in malformed:
        print("MALFORMED line " + str(ln), file=sys.stderr)
    avg = average(valid, key, total_lines=len(lines))
    print(render(len(valid), len(malformed), key_count(valid, key), avg))
    return 0

if __name__ == "__main__":
    sys.exit(main(sys.argv))
