import json

def render(valid_count, malformed_count, kc, avg):
    return json.dumps({"valid": valid_count, "malformed": malformed_count,
                       "key_count": kc, "average": avg})
