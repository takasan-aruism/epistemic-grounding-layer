import sys, os, subprocess, json
root = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
cli = os.path.join(root, "src", "cli.py")
failures = []
def check(name, cond):
    if not cond:
        failures.append(name)

r = subprocess.run(["python3", cli, os.path.join(root, "fixtures", "main.jsonl"), "value"],
                   capture_output=True, text=True)
check("main_exit0", r.returncode == 0)
parsed = None
try:
    parsed = json.loads(r.stdout)
    check("stdout_json_single_line", len(r.stdout.strip().splitlines()) == 1)
except Exception:
    check("stdout_json_single_line", False)
if parsed is not None:
    check("keys_exact", set(parsed.keys()) == {"valid", "malformed", "key_count", "average"})
    check("valid_count", parsed.get("valid") == 4)
    check("malformed_count", parsed.get("malformed") == 2)
    check("key_count", parsed.get("key_count") == 3)
    check("average_main", parsed.get("average") == 20.0)
else:
    failures.extend(["keys_exact", "valid_count", "malformed_count", "key_count", "average_main"])
check("stderr_malformed_lines",
      "MALFORMED line 3" in r.stderr and "MALFORMED line 6" in r.stderr)

m = subprocess.run(["python3", cli, os.path.join(root, "fixtures", "no_such.jsonl"), "value"],
                   capture_output=True, text=True)
check("missing_exit2", m.returncode == 2)
check("missing_stderr_error", "not found" in m.stderr)

z = subprocess.run(["python3", cli, os.path.join(root, "fixtures", "no_numeric.jsonl"), "value"],
                   capture_output=True, text=True)
try:
    check("zero_numeric_average_null", json.loads(z.stdout).get("average") is None)
except Exception:
    check("zero_numeric_average_null", False)

if failures:
    print("FAIL: " + ",".join(sorted(set(failures))))
    sys.exit(1)
print("PASS")
sys.exit(0)
