import sys, os, subprocess, json
root = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
cli = os.path.join(root, "src", "cli.py")
with open(os.path.join(root, "tests", "expected_result.json")) as f:
    expected = json.load(f)
failures = []
def check(name, cond):
    if not cond:
        failures.append(name)

r = subprocess.run(["python3", cli, os.path.join(root, "fixtures", "main.jsonl"), "value"],
                   capture_output=True, text=True)
check("main_exit0", r.returncode == 0)
parsed = None
try:
    parsed = json.loads(r.stdout)
    check("stdout_json_single_line", len(r.stdout.strip().splitlines()) == 1)
except Exception:
    check("stdout_json_single_line", False)
if parsed is not None:
    check("keys_exact", set(parsed.keys()) == {"valid", "malformed", "key_count", "average"})
    check("result_matches_expected", parsed == expected)
else:
    failures.extend(["keys_exact", "result_matches_expected"])
check("stderr_malformed_lines",
      "MALFORMED line 3" in r.stderr and "MALFORMED line 6" in r.stderr)

m = subprocess.run(["python3", cli, os.path.join(root, "fixtures", "no_such.jsonl"), "value"],
                   capture_output=True, text=True)
check("missing_exit2", m.returncode == 2)
check("missing_stderr_error", "not found" in m.stderr)

z = subprocess.run(["python3", cli, os.path.join(root, "fixtures", "no_numeric.jsonl"), "value"],
                   capture_output=True, text=True)
try:
    check("zero_numeric_average_null", json.loads(z.stdout).get("average") is None)
except Exception:
    check("zero_numeric_average_null", False)

if failures:
    print("FAIL: " + ",".join(sorted(set(failures))))
    sys.exit(1)
print("PASS")
sys.exit(0)
