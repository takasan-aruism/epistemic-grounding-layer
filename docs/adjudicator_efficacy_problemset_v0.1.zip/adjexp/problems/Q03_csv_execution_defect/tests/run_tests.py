import sys, os, subprocess
root = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
r = subprocess.run(["python3", os.path.join(root, "src", "csv_count.py"),
                    os.path.join(root, "fixtures", "data.csv")],
                   capture_output=True, text=True)
failures = []
def check(name, cond):
    if not cond:
        failures.append(name)

check("exit_code", r.returncode == 0)
check("stdout_rowcount", r.stdout.strip() == "3")
check("stderr_empty", r.stderr.strip() == "")

if failures:
    print("FAIL: " + ",".join(failures))
    sys.exit(1)
print("PASS")
sys.exit(0)
