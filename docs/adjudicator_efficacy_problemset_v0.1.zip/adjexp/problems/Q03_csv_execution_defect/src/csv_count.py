import sys, csv

def main(argv):
    if len(argv) != 2:
        print("ERROR: usage: csv_count.py <path>", file=sys.stderr)
        return 2
    with open(argv[1], newline="") as f:
        rows = list(csv.reader(f))
    print(len(rows) - 1 if rows else 0)
    return 0

if __name__ == "__main__":
    sys.exit(main(sys.argv))
