import sys, os, subprocess
root = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
src = os.path.join(root, "src", "normalize.py")
failures = []
def check(name, cond):
    if not cond:
        failures.append(name)

r1 = subprocess.run(["python3", src, "  Hello   WORLD "], capture_output=True, text=True)
check("exit_code", r1.returncode == 0)
check("stdout_normalized", r1.stdout.strip() == "hello world")
r2 = subprocess.run(["python3", src, "A\tB\nC"], capture_output=True, text=True)
check("whitespace_collapsed", r2.stdout.strip() == "a b c")

if failures:
    print("FAIL: " + ",".join(failures))
    sys.exit(1)
print("PASS")
sys.exit(0)
