import sys, re

def normalize(s):
    return re.sub(r"\s+", " ", s.strip()).lower()

def main(argv):
    if len(argv) != 2:
        print("ERROR: usage: normalize.py <text>", file=sys.stderr)
        return 2
    print(normalize(argv[1]))
    return 0

if __name__ == "__main__":
    sys.exit(main(sys.argv))
