#!/bin/bash
rm -rf "$(cd "$(dirname "$0")" && pwd)/fixtures"
exit 0
