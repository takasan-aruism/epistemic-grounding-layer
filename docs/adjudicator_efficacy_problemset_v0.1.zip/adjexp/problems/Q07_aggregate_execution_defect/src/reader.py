import json

def read_jsonl(path):
    with open(path) as f:
        return [json.loads(l) for l in f.read().splitlines() if l]
