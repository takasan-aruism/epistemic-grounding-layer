def aggregate(named_records):
    files = {name: len(recs) for name, recs in named_records.items()}
    return {"files": files, "total": sum(files.values())}
