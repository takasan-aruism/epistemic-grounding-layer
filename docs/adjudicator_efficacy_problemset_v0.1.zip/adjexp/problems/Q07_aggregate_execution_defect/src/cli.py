import sys, os, json
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from reader import read_jsonl
from aggregate import aggregate

def main(argv):
    if len(argv) < 2:
        print("ERROR: usage: cli.py <file> [...]", file=sys.stderr)
        return 2
    named = {}
    for p in argv[1:]:
        try:
            named[os.path.basename(p)] = read_jsonl(p)
        except FileNotFoundError:
            print("ERROR: input file not found: " + p, file=sys.stderr)
            return 2
    print(json.dumps(aggregate(named)))
    return 0

if __name__ == "__main__":
    sys.exit(main(sys.argv))
