import sys, os, subprocess, json
root = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
cli = os.path.join(root, "src", "cli.py")
fa = os.path.join(root, "fixtures", "a.jsonl")
fb = os.path.join(root, "fixtures", "b.jsonl")
failures = []
def check(name, cond):
    if not cond:
        failures.append(name)

r = subprocess.run(["python3", cli, fa, fb], capture_output=True, text=True)
check("exit0", r.returncode == 0)
parsed = None
try:
    parsed = json.loads(r.stdout)
    check("stdout_json", True)
except Exception:
    check("stdout_json", False)
if parsed is not None:
    check("keys_exact", set(parsed.keys()) == {"files", "total"})
    check("count_a", parsed.get("files", {}).get("a.jsonl") == 3)
    check("count_b", parsed.get("files", {}).get("b.jsonl") == 2)
    check("total", parsed.get("total") == 5)
else:
    failures.extend(["keys_exact", "count_a", "count_b", "total"])
check("stderr_empty", r.stderr.strip() == "")

if failures:
    print("FAIL: " + ",".join(sorted(set(failures))))
    sys.exit(1)
print("PASS")
sys.exit(0)
