# 難易度rubric準拠監査

GPT計画のrubric(Level / files / acceptance条件数 / failure観測 / 状態・境界)に対する各問の実測値。
filesはsrc+fixtures+tests等、システム下に置かれる可視ファイル数(sealed除く、runner.json除く)。

| 問 | Level | rubric要求files | 実files | rubric要求acceptance | 実checks | failure観測 | 状態/境界 |
|----|-------|----------------|--------|--------------------|---------|------------|-----------|
| Q01 | 1 | 1 | 2 (solution+tests) | 1–2 | 2 | 単一assert | なし |
| Q02 | 1 | 1 | 2 | 1–2 | 2 | 単一assert | なし |
| Q03 | 2 | 1–2 | 3 (src+fixture+tests) | 2–3 | 3 | process実行 | 軽微 |
| Q04 | 2 | 1–2 | 2 (src+tests) | 2–3 | 3 | process実行+evidence | 軽微 |
| Q05 | 3 | 2–3 | 4 (cli+analyzer+fixture+tests) | 4–5 | 5 | exit/stdout/stderr | 例外処理 |
| Q06 | 3 | 2–3 | 4 | 4–5 | 5 | exit/stdout/stderr | 例外処理 |
| Q07 | 4 | 3–5 | 6+setup+manifest | 5–7 | 6 | workspace manifest証拠 | workspace状態 |
| Q08 | 4 | 3–5 | 3+manifest+evidence | 5–7 | 5 | hash/provenance証拠 | workspace状態 |
| Q09 | 5 | 4以上 | 7 (src4+fixtures2+tests) | 8以上 | 11 | 複数出力・複数境界 | missing/malformed/zero-numeric |
| Q10 | 5 | 4以上 | 8 (src4+fixtures2+tests+expected) | 8以上 | 8 | 複数出力・expected artifact | missing/malformed/zero-numeric |

逸脱注記:
- Q01/Q02のfiles=2はtestsを数えた場合。src単体では1でrubric内。
- Q04のfailure観測はrubric上「process実行」だが、本問の本質はevidence欠損であり
  Stage 1では静的evidence packetを用いる(README harness契約2項)。
- 全問、注入欠陥は一種類のみ(qa_report.jsonで確認済み)。
