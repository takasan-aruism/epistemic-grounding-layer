# FIX-01r2 出荷マニフェスト(CONTENT_SEAL 付き・DE-0485 対応)

authority: SEAL-2026-07-21 §4。date: 2026-07-21。

## 裁定(Claude Code 報告 §8 の4件)
1. 仕様2点固定 = 採用。spec r2 に LBP-RET(戻り値契約の明文化: 自 repo の
   RECONCILIATION_* が無ければ (None, False)。global 最後を返して False は
   契約違反)と RP-INV(realpath 両辺適用の退行禁止不変条件 + T-3 を番人と
   名指し)を本文化。テストは FIX-01r 版から**不変**(b0293993)。
2. アクター変更 = 条件付き採用(単一変数規律):
   - r2 run: FIX01r2.json(同一アクター 35B・仕様修正のみが変数)。
   - **事前授権**: r2 が BUDGET_EXHAUSTED の場合のみ、FIX01r2b.json
     (27B-Coder :8006。差分は model/endpoint のみ、sed 生成)で次の1 run。
     ※ r2b の model 名は Claude Code が実測の正確な名称に修正してよい
     (:8006 で serve されている実名。修正した場合は記帳)。
   - 帰属: r2 で PASS → 仕様欠陥が原因と確定。r2b で PASS → モデル能力が
     原因と確定。両方 EXHAUSTED → STOP して設計へ差戻し。
3. bundle-a v1.2 の封印: SEAL §6 に触れない(R1-5a は封印済み R1-5 の解釈
   詳細であり新規構築でない)。§4 の CONTENT_SEAL 委任範囲内として v1.2
   (sha 0739a1ef)を正式封印。機械検証用に v1.1 原本と unified diff を同梱
   — v1.1(147d39b2)+ diff 適用 = v1.2 をバイト照合で確認し記帳のこと。
4. FIX-01-OP は次便で発行(実装が immutable を通過するまで回帰測定は開始
   できないため、クリティカルパス阻害なし)。

## 充足性(r2 spec に対する再確認)
テスト不変・契約意味不変のため、参照実装(strong)で 16/16 passed を再測済み。

## 同梱物
FIX01_spec.md(r2)/ FIX01r2.json / FIX01r2b.json /
bundle-a-remediation-spec-v1.1.md(原本)/ bundle-a_v1.1_to_v1.2.diff /
SHA256SUMS.txt
(テストと v1.2 は前便 FIX01r_shipment のバイトのまま。再同梱しない。)
