# FIX-01c + FIX-01-OP 出荷マニフェスト(CONTENT_SEAL 付き)

authority: SEAL-2026-07-21 §4。date: 2026-07-21。DE-0486 への応答便。

## 0. 開示(設計側の契約欠陥)
FIX-01 契約は emit の repo 場必須化に対し、内部呼出者 apply_patch_bounded への
貫通を欠いた。live twoder は apply 経路が書込み後 ValueError で停止し未記録
書込みを作り得る状態(非通電・運用露出ゼロ・大音量故障・reconciler が不均衡
として検出する側)。immutable tests が apply 経路を触らなかったため Qwen にも
監査にも不可視だった。是正 = FIX-01c。教訓は DE-0484 系に追記を依頼:
「契約変更時は、変更対象 API の**全内部呼出者**を契約に含める」。

## 1. FIX-01c(packet)
- spec は TEMPLATE 方式: live patch_bridge.py(f9976588)を Claude Code が
  staging 時に機械挿入し、組立後 sha を記帳(挿入は起草ではない・CC-2 範囲)。
- 契約: repo_identity 必須 + token 交差検査 + **realpath は内部導出**
  (caller 供給禁止・封印原則)+ APPLIED/ROLLED_BACK 両 emit へ貫通 +
  connector は token identity を渡す + テスト minter も identity 束縛。
- immutable tests 6本。充足性: 参照実装で 6/6 passed(使い捨て・破棄済)。

## 2. FIX-01-OP(oracle 配管・FIX-01c 適用後に実施)
- OP_oracles/ に更新済み oracle 7本 + unified diff 7本(うち2本は差分ゼロ =
  無変更)。総差分 246 行、**全て呼出配管と fixture への repo 場付加。
  assertion の変更ゼロ**(diff で機械レビュー可能)。
- 検証済み(参照実装に対する実測): reconciler 7/7 / minter 18/18 /
  throwaway E2E 7/7 / jrev0010 6攻撃 0 BREACH / §4 gate 11注入 0 SLIPPED /
  harness PASS / read-only gate PASS / FIX-01r2 immutable 16/16 無退行。
- 実行手順(operator.py shadow 対策・DE-0486 §5(b)): 回帰は**分離ディレクトリ**
  で実施 — 3モジュール + oracle 群のみを空ディレクトリへ copy し、そこで実行。
  twoder/ を sys.path に載せない。gate_reconciler_readonly の引数は
  モジュールファイル(例: `python3 gate_reconciler_readonly.py
  bridge_reconciler.py`)。

## 3. 工程順序
FIX-01c run → 監査・適用 → OP oracle 差替(diff レビュー→copy)→ 分離 dir で
回帰全走 → 無退行を記帳。ここで FIX-LIFT terminal 第2項が成立。
その後 FIX-02(R2+R3: apply 時再検査 + claim 原子化 + clock)→ FIX-03
(CORRECTION)→ JREV-0010r(全修復概念への novel attack)→ terminal 第3項
→ auto-refreeze。

## 4. 残余判断への回答(DE-0486 §7)
- JREV-0010r 起動 = FIX-03 終端後(修復3概念が全て実装に存在してから)。
- 27B 経路 = 採用保留。r2 帰属確定によりモデル変更の必要が消えた。将来
  必要になれば §5(a) の unit/proxy 構築を別裁定(SEAL §6 = Taka 印)として
  起票する。今回は構築しない。
