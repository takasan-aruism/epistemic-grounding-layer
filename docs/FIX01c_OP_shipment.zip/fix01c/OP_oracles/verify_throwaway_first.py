"""§2 throwaway-first integration E2E (Taka build order: A -> A verified -> B -> B checks A liveness ->
throwaway-first 1-patch apply -> rollback confirm -> STOP before commit).

Runs the FULL canonical flow on a THROWAWAY repo, wiring reconciler (A) + minter (B) + bridge together:
  0. reconcile baseline -> zero-orphan equilibrium (bootstrap) + emit balance proof.
  1. Taka ENERGIZATION_ADJUDICATION -> B mints a fully-bound token (B refuses without A's fresh proof).
  2. token drives ONE real bridge apply -> APPLIED; reconciler re-confirms BALANCED.
  3. rollback: a mid-apply failure ROLLS BACK a partially-written change -> file restored; reconciler BALANCED.
  4. STOP before commit: HEAD is unchanged throughout and NO git commit is ever invoked (commit = Taka, OOS).
No canonical repo is touched; everything is under the OS temp root."""
import sys, os, subprocess, tempfile, shutil, hashlib
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
import patch_bridge as pb
import bridge_reconciler as rc
import bridge_minter as bm
REPO_IDENT = 'throwaway'   # FIX-01-OP plumbing: matches this oracle's existing minter-request repo_identity

results = []
def check(name, ok, detail=''):
    results.append((name, ok)); print('[%s] %-32s %s' % ('OK' if ok else '**FAIL**', name, detail))

NOW, EXP = '2026-07-18T10:00:00', '2026-07-18T23:59:59'

class Log:
    def __init__(self): self.ev = []
    def recorder(self, task_id, kind, payload, ts, identity='x'):
        self.ev.append({'task_id':task_id,'kind':kind,'payload':payload,'ts':ts,'identity':identity})
        return (kind,(payload or {}).get('outcome'))
    def pa(self): return [e for e in self.ev if e['kind']=='PATCH_APPLICATION']

def sha(p):
    with open(p,'rb') as f: return hashlib.sha256(f.read()).hexdigest()

d = tempfile.mkdtemp(prefix='tf_')
try:
    for c in (['git','init','-q',d],['git','-C',d,'config','user.email','t@t'],['git','-C',d,'config','user.name','t']):
        subprocess.run(c, check=True)
    for fn in ('a.py','b.py','c.py'):
        open(os.path.join(d,fn),'w').write('OLD_%s\n'%fn)
    subprocess.run(['git','-C',d,'add','.'], check=True)
    subprocess.run(['git','-C',d,'commit','-qm','init'], check=True)
    HEAD0 = subprocess.run(['git','-C',d,'rev-parse','HEAD'],capture_output=True,text=True).stdout.strip()
    real = os.path.realpath(d)
    log = Log()

    # ---- 0. bootstrap baseline + proof ----
    res0 = rc.reconcile(d, [], REPO_IDENT)
    rc.emit_reconciliation(log.recorder, 'T', res0, 'ts0')
    check('0_bootstrap_baseline', res0.balanced and res0.baseline, 'zero-orphan equilibrium before first apply')

    # B must depend on A's liveness: with NO proof in the log, minting is refused (fail-closed)
    base = pb.capture_provenance(d, ['a.py']).base_commit
    art1 = pb.worker_output_to_artifact('+ NEW_A', ['a.py'], base)
    req1 = {'item_id':'IT-A','task_id':'TK-A','trace_id':'TR-A','repo_identity':'throwaway','repo_realpath':real,
            'base_commit':base,'allowed_files':['a.py'],'fingerprint':art1['fingerprint'],
            'token_id':'TOK-A','adjudication_id':'ADJ-A'}
    adj1 = {'kind':'ENERGIZATION_ADJUDICATION','ts':'ts','payload':{
        'adjudication_id':'ADJ-A','authority_owner':'TAKA','granted_by':'TAKA','attribution':'TAKA',
        'item_id':'IT-A','repo_realpath':real,'base_commit':base,'fingerprint':art1['fingerprint'],
        'allowed_files':['a.py'],'expires_at':EXP}}
    liveness_refused = False
    try:
        bm.mint_real_energize(req1, [adj1], d, now_ts=NOW)   # log WITHOUT a fresh proof
    except bm.MintRefused:
        liveness_refused = True
    check('1_B_requires_A_liveness', liveness_refused, 'minter refuses without a fresh reconciler proof')

    # ---- 1-2. Taka adjudication -> mint (with proof present) -> ONE real apply ----
    log.ev.append(adj1)
    tok1 = bm.mint_real_energize(req1, log.ev, d, now_ts=NOW)
    prov = pb.capture_provenance(d, ['a.py'])
    r = pb.bridge_apply_connector(tok1, d, art1, ['a.py'], prov, log.recorder, 'TK-A', 'ts_apply')
    applied_ok = r.get('applied') is True and sha(os.path.join(d,'a.py'))==art1['fingerprint']
    check('2_one_real_apply', applied_ok, 'APPLIED; on-disk a.py == fingerprint')
    res1 = rc.reconcile(d, log.pa(), REPO_IDENT)
    rc.emit_reconciliation(log.recorder, 'T', res1, 'ts1')
    check('2b_reconciler_balanced_after_apply', res1.balanced and not res1.baseline,
          'balanced (a.py change explained by APPLIED event)')

    # ---- 3. rollback: a write occurs, a subsequent preimage guard trips, automatic rollback restores it ----
    base2 = pb.capture_provenance(d, ['b.py']).base_commit
    art2 = pb.worker_output_to_artifact('+ NEW_B', ['b.py'], base2)
    req2 = {'item_id':'IT-B','task_id':'TK-B','trace_id':'TR-B','repo_identity':'throwaway','repo_realpath':real,
            'base_commit':base2,'allowed_files':['b.py'],'fingerprint':art2['fingerprint'],
            'token_id':'TOK-B','adjudication_id':'ADJ-B'}
    log.ev.append({'kind':'ENERGIZATION_ADJUDICATION','ts':'ts','payload':{
        'adjudication_id':'ADJ-B','authority_owner':'TAKA','granted_by':'TAKA','attribution':'TAKA',
        'item_id':'IT-B','repo_realpath':real,'base_commit':base2,'fingerprint':art2['fingerprint'],
        'allowed_files':['b.py'],'expires_at':EXP}})
    # fresh proof for base2 (== HEAD, no commit happened) so freshness holds
    resB = rc.reconcile(d, log.pa(), REPO_IDENT); rc.emit_reconciliation(log.recorder,'T',resB,'ts_bp')
    tok2 = bm.mint_real_energize(req2, log.ev, d, now_ts=NOW)
    before_b = open(os.path.join(d,'b.py')).read()
    # expected_preimage pinned to the ORIGINAL bytes: the writer writes b.py, then the preimage guard
    # re-checks and sees the now-changed bytes -> raises -> apply_patch_bounded auto-rolls-back to original.
    pinned_pre = {'b.py': sha(os.path.join(d,'b.py'))}
    raised = False
    try:
        pb.apply_patch_bounded(d, art2, ['b.py'], log.recorder, 'TK-B', 'ts_rb',
                               energize=tok2, expected_base=base2, expected_fingerprint=art2['fingerprint'],
                               expected_preimage=pinned_pre,
                               repo_identity=REPO_IDENT)
    except ValueError:
        raised = True
    rolled = ('PATCH_APPLICATION','ROLLED_BACK') in [(e['kind'],e['payload'].get('outcome')) for e in log.pa()]
    restored = open(os.path.join(d,'b.py')).read()==before_b
    no_applied_b = not any(e['payload'].get('outcome')=='APPLIED' and 'b.py' in (e['payload'].get('filenames') or [])
                           for e in log.pa())
    check('3_rollback_restores_write', raised and rolled and restored and no_applied_b,
          'write rolled back; b.py restored to pre-apply bytes; ROLLED_BACK emitted')
    resR = rc.reconcile(d, log.pa(), REPO_IDENT)
    check('3b_reconciler_balanced_after_rollback', resR.balanced,
          'balanced (only a.py dirty, explained; b/c reverted)')

    # ---- 4. STOP before commit ----
    HEAD1 = subprocess.run(['git','-C',d,'rev-parse','HEAD'],capture_output=True,text=True).stdout.strip()
    ncommits = subprocess.run(['git','-C',d,'rev-list','--count','HEAD'],capture_output=True,text=True).stdout.strip()
    check('4_stop_before_commit', HEAD1==HEAD0 and ncommits=='1',
          'HEAD unchanged, still 1 commit (no commit invoked; commit=Taka, out of scope)')
finally:
    shutil.rmtree(d, ignore_errors=True)

fails = [n for n,ok in results if not ok]
print('\n=== §2 THROWAWAY-FIRST E2E: %d checks, %d FAIL ===' % (len(results), len(fails)))
sys.exit(0 if not fails else 2)
