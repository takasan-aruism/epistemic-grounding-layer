#!/usr/bin/env python3
"""DE-0417 counterfactual (self-contained). Reproduces the DE-0413 discrepancy CLASS — the build harness
accepting worker out_code whose bytes, integrated into the base module and run DIRECTLY against the oracle,
FAIL — and proves the repaired harness LAYER-3 re-verify catches it.

This is the DE-0392 under-determination family's 3rd term: code -> oracle -> HARNESS. The pipeline sandbox's
pass-signal is NOT a reliable proxy for "the committed bytes pass the oracle when run directly". LAYER-3
gates SUCCESS on exactly that direct run. Throwaway only; canonical stores untouched.

Run: python3 regression/test_harness_reverify.py   (exit 0 = fix works)
"""
import os, sys, tempfile, shutil, subprocess

# A minimal base module: the collaborators the oracle monkeypatches must EXIST so the module imports.
BASE = """from dataclasses import dataclass

@dataclass(frozen=True)
class _ValidatedPatch:
    diff: object
    filenames: tuple
    base_commit: str
    fingerprint: str

def canonical_diff_artifact(diff_text, base_commit):
    return {"schema_version": "unified-diff-v1", "base_commit": base_commit, "fingerprint": "real", "diff": diff_text}

def validate_artifact(artifact, allowed_files, expected_base=None, expected_fingerprint=None):
    return _ValidatedPatch(artifact["diff"], (), expected_base, expected_fingerprint)

def check_diff_within_allowed(diff_text, allowed_files):
    return []

def apply_patch_bounded(workspace_dir, artifact, allowed_files, recorder, task_id, ts,
                        expected_base=None, expected_fingerprint=None):
    return {"outcome": "APPLIED"}
"""

# The oracle (recompute-assert connector oracle: fakes validate_artifact as a 4-arg lambda).
ORACLE = '''try:
    import patch_bridge as pb
except ImportError:
    print("FAIL: not found"); raise SystemExit(1)
def _fail(m):
    print("FAIL:", m); raise SystemExit(1)
def test_block():
    r = pb.bridge_apply_connector(None, "ws", {}, [], None, None, "t", "ts")
    if r.get("applied") is not False or r.get("blocked") != "NOT_ENERGIZED":
        _fail("must block without token")
class _P:
    base_commit = "BC"; allowed_files = ("impl.py",)
class _V:
    diff = "DT"
def test_energized():
    c = []
    pb.canonical_diff_artifact = lambda d, b: c.append(("canon", d, b)) or {"fingerprint": "RECOMP"}
    pb.validate_artifact = lambda a, af, base, fp: c.append(("v", base, fp)) or _V()
    pb.check_diff_within_allowed = lambda dt, af: c.append(("c", dt, af))
    pb.apply_patch_bounded = lambda w, a, af, r, t, s, expected_base=None, expected_fingerprint=None: c.append(("a", expected_base, expected_fingerprint)) or {"ok": 1}
    out = pb.bridge_apply_connector(pb._EnergizedApply(grant="g"), "WS", {"diff": "D", "base_commit": "BC0", "fingerprint": "CLAIMED"}, ["impl.py"], _P(), "R", "T", "S")
    if [x[0] for x in c] != ["canon", "v", "c", "a"]:
        _fail("must recompute fingerprint before validate")
    if c[1][1] != "BC" or c[1][2] != "RECOMP":
        _fail("validate must get provenance.base_commit and the RECOMPUTED fingerprint")
    if out.get("applied") is not True:
        _fail("energized applied True")
test_block(); test_energized(); print("PASS")
'''

# WRONG worker out_code: energized path mis-wires validate_artifact (2 args; oracle fake needs 4).
WRONG = """from dataclasses import dataclass

@dataclass(frozen=True)
class _EnergizedApply:
    grant: str

def bridge_apply_connector(energize_token, workspace_dir, artifact, allowed_files, provenance, recorder, task_id, ts):
    if not isinstance(energize_token, _EnergizedApply):
        return {'applied': False, 'blocked': 'NOT_ENERGIZED'}
    fingerprint = canonical_diff_artifact(artifact['diff'], artifact['base_commit'])['fingerprint']
    validate_artifact(artifact, fingerprint)
    check_diff_within_allowed(artifact['diff'], allowed_files, fingerprint)
    return {'applied': True}
"""

# CORRECT worker out_code.
CORRECT = """from dataclasses import dataclass

@dataclass(frozen=True)
class _EnergizedApply:
    grant: str

def bridge_apply_connector(energize_token, workspace_dir, artifact, allowed_files, provenance, recorder, task_id, ts):
    if not isinstance(energize_token, _EnergizedApply):
        return {'applied': False, 'blocked': 'NOT_ENERGIZED', 'reason': 'x'}
    expected_fp = canonical_diff_artifact(artifact['diff'], artifact['base_commit'])['fingerprint']
    validated = validate_artifact(artifact, allowed_files, provenance.base_commit, expected_fp)
    check_diff_within_allowed(validated.diff, provenance.allowed_files)
    result = apply_patch_bounded(workspace_dir, artifact, allowed_files, recorder, task_id, ts,
                                 expected_base=provenance.base_commit, expected_fingerprint=expected_fp)
    return {'applied': True, 'result': result}
"""


def layer3_reverify(out_code):
    """The LAYER-3 logic run_fn6 runs before SUCCESS: integrate (base + out_code), run the oracle DIRECTLY."""
    rv = tempfile.mkdtemp(prefix="reverify_")
    try:
        open(os.path.join(rv, "patch_bridge.py"), "w").write(BASE.rstrip("\n") + "\n\n" + out_code + "\n")
        open(os.path.join(rv, "unit.py"), "w").write(ORACLE)
        rc = subprocess.run(["python3", "unit.py"], cwd=rv, capture_output=True, text=True, timeout=60)
        return rc.returncode
    finally:
        shutil.rmtree(rv, ignore_errors=True)


if __name__ == "__main__":
    wrong_rc = layer3_reverify(WRONG)
    correct_rc = layer3_reverify(CORRECT)
    print("WRONG   out_code -> LAYER-3 rc=%d (%s)" % (wrong_rc, "REJECTED (caught)" if wrong_rc else "*** SLIPPED ***"))
    print("CORRECT out_code -> LAYER-3 rc=%d (%s)" % (correct_rc, "ACCEPTED" if correct_rc == 0 else "*** false-reject ***"))
    ok = wrong_rc != 0 and correct_rc == 0
    print("PASS" if ok else "FAIL")
    sys.exit(0 if ok else 1)
