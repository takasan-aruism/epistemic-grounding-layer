"""FIX-01c immutable tests — apply-path repo identity threading.
SEAL-2026-07-21 §4 / FIX-LIFT-JREV0010. DO NOT MODIFY (contract).
Contract: apply_patch_bounded requires repo_identity (fail-closed), cross-checks it
against the energize token's binding, derives repo_realpath from workspace_dir
internally (never caller-supplied), and threads both into APPLIED/ROLLED_BACK
PATCH_APPLICATION payloads. bridge_apply_connector passes the token's identity.
_mint_test_energize binds repo_identity (default 'throwaway')."""
import os, subprocess, tempfile, shutil
import pytest
import patch_bridge as pb

def _git(d, *a):
    r = subprocess.run(['git', '-C', d, *a], capture_output=True, text=True)
    assert r.returncode == 0, r.stderr
    return r.stdout

@pytest.fixture()
def ws(request):
    d = tempfile.mkdtemp(prefix='fix01c_')
    request.addfinalizer(lambda: shutil.rmtree(d, ignore_errors=True))
    subprocess.run(['git', 'init', '-q', d], check=True)
    _git(d, 'config', 'user.email', 't@t'); _git(d, 'config', 'user.name', 't')
    with open(os.path.join(d, 'impl.py'), 'wb') as f: f.write(b'orig\n')
    _git(d, 'add', '.'); _git(d, 'commit', '-q', '-m', 'init')
    return d

class Log:
    def __init__(self): self.ev = []
    def recorder(self, task_id, kind, payload, ts, identity=None):
        self.ev.append({'kind': kind, 'payload': payload, 'ts': ts}); return {'ok': True}
    def pa(self): return [e for e in self.ev if e['kind'] == 'PATCH_APPLICATION']

def _setup(ws, ident='tw'):
    prov = pb.capture_provenance(ws, ['impl.py'])
    art = pb.worker_output_to_artifact('+ NEW', ['impl.py'], prov.base_commit)
    tok = pb._mint_test_energize(ws, repo_identity=ident)
    return prov, art, tok

def test_apply_requires_repo_identity(ws):
    prov, art, tok = _setup(ws)
    with pytest.raises(ValueError):
        pb.apply_patch_bounded(ws, art, ['impl.py'], Log().recorder, 'T', 'ts',
                               energize=tok, expected_base=prov.base_commit,
                               expected_fingerprint=art['fingerprint'])

def test_apply_identity_token_crosscheck(ws):
    prov, art, tok = _setup(ws, ident='tw')
    with pytest.raises(ValueError):
        pb.apply_patch_bounded(ws, art, ['impl.py'], Log().recorder, 'T', 'ts',
                               energize=tok, expected_base=prov.base_commit,
                               expected_fingerprint=art['fingerprint'],
                               repo_identity='OTHER')          # != token binding

def test_applied_payload_carries_identity_and_derived_realpath(ws):
    prov, art, tok = _setup(ws, ident='tw')
    log = Log()
    pb.apply_patch_bounded(ws, art, ['impl.py'], log.recorder, 'T', 'ts',
                           energize=tok, expected_base=prov.base_commit,
                           expected_fingerprint=art['fingerprint'], repo_identity='tw')
    pa = log.pa()[-1]['payload']
    assert pa['outcome'] == 'APPLIED'
    assert pa['repo_identity'] == 'tw'
    assert pa['repo_realpath'] == os.path.realpath(ws)          # derived, not supplied

def test_rolled_back_payload_carries_identity(ws):
    prov, art, tok = _setup(ws, ident='tw')
    log = Log()
    pinned = {'impl.py': 'f' * 64}                               # wrong preimage -> refuse+rollback
    with pytest.raises(Exception):
        pb.apply_patch_bounded(ws, art, ['impl.py'], log.recorder, 'T', 'ts',
                               energize=tok, expected_base=prov.base_commit,
                               expected_fingerprint=art['fingerprint'],
                               expected_preimage=pinned, repo_identity='tw')
    pa = log.pa()[-1]['payload']
    assert pa['outcome'] == 'ROLLED_BACK'
    assert pa['repo_identity'] == 'tw'
    assert pa['repo_realpath'] == os.path.realpath(ws)

def test_connector_threads_token_identity(ws):
    prov, art, tok = _setup(ws, ident='tw')
    log = Log()
    r = pb.bridge_apply_connector(tok, ws, art, ['impl.py'], prov, log.recorder, 'T', 'ts')
    assert r['applied'] is True
    pa = log.pa()[-1]['payload']
    assert pa['repo_identity'] == 'tw'

def test_test_minter_binds_default_identity(ws):
    tok = pb._mint_test_energize(ws)
    assert tok.repo_identity == 'throwaway'
