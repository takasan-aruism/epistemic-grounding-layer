# FIX-01c 仕様 — apply 経路の repo identity 貫通(FIX-01 契約の完結)

authority: SEAL-2026-07-21 §4。DE-0486 後続。
背景: FIX-01 契約は emit_patch_application に repo 場を必須化したが、内部呼出者
(apply_patch_bounded の APPLIED/ROLLED_BACK 2箇所)への貫通を欠いた(設計側の
契約欠陥として開示済み)。現 live 状態では apply 経路が書込み後 ValueError で
停止し未記録書込みを作り得る(非通電につき運用露出ゼロ・落ち方は大音量)。

実装対象: patch_bridge.py のみを完全ファイルとして再出力。

## 変更契約
1. apply_patch_bounded 新シグネチャ: 末尾に repo_identity=None を追加。
   - repo_identity が falsy → ValueError('apply_patch_bounded requires
     repo_identity (fail-closed)')。
   - energize token が repo_identity を持つ場合、引数と不一致 → ValueError
     ('repo_identity != energize token binding (fail-closed)')。token が
     None または identity 未束縛(テスト token 旧形)なら交差検査は skip。
   - _repo_realpath = os.path.realpath(workspace_dir) を内部導出する。
     **caller から realpath を受けてはならない**(封印原則: 書込み先を
     騙る余地を残さない)。
   - APPLIED / ROLLED_BACK 両方の emit_patch_application 呼出に
     repo_identity=repo_identity, repo_realpath=_repo_realpath を付加。
2. bridge_apply_connector: apply_patch_bounded 呼出に
   repo_identity=energize_token.repo_identity を付加(シグネチャ不変。
   token 検査で早期 return 済みのため identity は必ず存在)。
3. _mint_test_energize 新シグネチャ: (workspace_dir, repo_identity='throwaway')。
   生成する _EnergizedApply に repo_identity を束縛する。
4. 上記以外の関数・定数・挙動は一切変更しない。

## 現行ソース
<current_source path="patch_bridge.py">
{{INSERT_LIVE_TWODER_BYTES sha256=f9976588e7909c27e6d9ccebbc4c6d399f5c94027019fb8c4c5fc3ed2752db2d}}
</current_source>
※ Claude Code が staging 時に live バイトを機械挿入し、組立後 spec の sha256 を
記帳する(CC-2 範囲の機械作業。内容の起草ではない)。
