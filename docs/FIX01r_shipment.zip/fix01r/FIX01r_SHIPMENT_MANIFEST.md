# FIX-01r 出荷マニフェスト(CONTENT_SEAL 付き・DE-0484 対応)

authority: SEAL-2026-07-21 §4。date: 2026-07-21。
DE-0484(Qwen 実装が immutable 10/10 を通過しつつ latest_balance_proof の
repo 絞込契約に非適合)への処置。**Claude Code の監査判断(適用保留)を追認**。

## 処置
1. spec は不変(契約は当初から絞込を要求。FIX01_spec.md sha 76d9c724 のまま)。
2. immutable tests を強化: LBP 直接契約テスト6本を追加(計16本)。
3. 検証(両方とも使い捨て・破棄済み):
   - 充足性: 契約準拠の参照実装で 16/16 passed。
   - 被覆性: DE-0484 型変異体(LBP 絞込なし・minter 側検査で代償)で
     新テスト4本が FAILED(4 failed, 12 passed)。非適合実装類は
     本スイートで機械的に落ちることを実測。
4. 教訓の恒久化を提案(DE 起票を依頼): 「参照実装は充足性のみを証明する。
   被覆性は契約違反変異体の不合格で証明する」(DE-0437 positive-control の
   テスト側双対)。

## Claude Code の手順
1. 新テストの sha 照合 → staging 差替(spec/packet は不変、テストのみ差替)。
2. 【配備側変異検証】保留中の Qwen 実装(run d5f38a3f の産物)に対して
   新スイートを実行し、FAILED になることを実測・記帳(変異体の実在検証)。
3. FIX-01r として新規 run を起動(既往記録機構はそのまま働く)。
4. PASS 後は前回どおり: 適用後 sha 記帳 → FIX-01-OP(次便)待ち。

## 同便の別件
- bundle-a-remediation-spec-v1.2.md: R1-5a(CORRECTION の原 event 識別 =
  {store, line_index, line_sha256} 三つ組。DE-0483 への裁定)を追記。
- watcher-layer-design-v0.4.1.md / bundle-a v1.2 を同梱(DE-0482 の
  「捺印対象文書が SoR 不在」の解消。egl docs へ commit を)。
