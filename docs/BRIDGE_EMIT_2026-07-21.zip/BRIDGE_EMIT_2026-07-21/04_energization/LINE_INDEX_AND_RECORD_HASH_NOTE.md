# ENERGIZATION_OBSERVATIONS.jsonl — 行識別子インデックス

**重要 / 依頼との差分**: この event store の record には **record_hash 場が存在しません**
(全7 record の key = task_id / kind / payload / ts / identity のみ。`grep -c record_hash` = 0)。
R1-5 の CORRECTION 起草で参照すべき「原 record_hash」は **記録されていない** ため、
下表の sha256 は **Claude Code が 2026-07-21 にその場で計算した値** であり、原記録の一部ではありません。
CORRECTION が参照する識別子をこの計算値に置くか、別の識別方式(行番号 + task_id + token_id + ts)に
するかは設計側の裁定事項です。詳細は DE-0483。

計算方法: 該当行の生バイト(末尾改行を除く)の sha256。ファイル自体は無改変で同梱。

| # | kind | task_id | token_id | ts | outcome | sha256(line bytes) |
|---|---|---|---|---|---|---|
| 1 | RECONCILIATION_BALANCED | ENERGIZE-01 | - | 2026-07-19T04:59:00+09:00 | balanced=True | `773e0bce72e52997bd32ba4fc082c8effc3dd7c303894cc1e9b2e78997d65963` |
| 2 | PATCH_APPLICATION | TASK-ENERGIZE-01 | TOK-ENERGIZE-01 | 2026-07-19T05:00:00+09:00 | APPLIED | `0d75f016246af06b68a9ad60b6f8a399cdda70b47eb68e21e8637974a06135ed` |
| 3 | RECONCILIATION_BALANCED | ENERGIZE-01 | - | 2026-07-19T05:01:00+09:00 | balanced=True | `140068b9f48c87a9081e806a4c9d3ed90891d844e1ede64847e64628f8016c3b` |
| 4 | PATCH_APPLICATION | TASK-ENERGIZE-01 | TOK-ENERGIZE-01 | 2026-07-19T05:02:00+09:00 | ROLLED_BACK | `6cfdba63757fcc985a4f65ff24a2a7e44e06b8746a86628170a33a9b66d06314` |
| 5 | RECONCILIATION_BALANCED | ENERGIZE-01 | - | 2026-07-19T05:14:00+09:00 | balanced=True | `7afc8ef0dc73069e5bd7734054e3b14c839ee847f83c6e03504601fd8879ca41` |
| 6 | PATCH_APPLICATION | TASK-ENERGIZE-02 | TOK-ENERGIZE-02 | 2026-07-19T05:15:00+09:00 | APPLIED | `d4c65992513949991bc847052fbebc024bd812aaec6452243c44d9dd53aca068` |
| 7 | RECONCILIATION_BALANCED | ENERGIZE-01 | - | 2026-07-19T05:20:00+09:00 | balanced=True | `e4e59cb074d12c3b11fe6a05e1ae09f56d5bd7f455175ef3b666914c94db3243` |

## R1-5 の対象 = PATCH_APPLICATION 3件(行 2 / 4 / 6)

ファイル全体(7 record)を同梱しているのは、RECONCILIATION_BALANCED との時系列関係
(freshness 判定の根拠)が CORRECTION 設計に要るためです。

## PA record が repo を語っていないこと(F1 の実体)

3件の PA payload は outcome / fingerprint / base_commit / filenames / token_id のみで、
**repo identity 場が無い**。参考同梱の ENERGIZATION_LEDGER.jsonl 側の
ENERGIZATION_ADJUDICATION 2件のみが repo_identity="rri" / repo_realpath を保持しています。
DE-0479 の遡及確認はこの非対称性を代理指標で埋めたものです。
