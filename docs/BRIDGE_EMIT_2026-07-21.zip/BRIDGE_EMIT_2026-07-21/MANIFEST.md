# 束A/W1A 着工資材 — MANIFEST（2026-07-21）

宛先: Claude Web（Taka 経由）
作成: Claude Code（CC-0 / INSPECTION_ONLY。本束は**既存バイトの収集**であり、
新規執筆・改変は 0 件。本 MANIFEST と `04_energization/LINE_INDEX_AND_RECORD_HASH_NOTE.md`
のみが本セッション生成物）
検証: `sha256sum -c SHA256SUMS.txt`

## 依頼 sha との照合（全一致）

| ファイル | 依頼された sha 前置 | 実測 sha256 | 判定 |
|---|---|---|---|
| patch_bridge.py | 5ca50050 | `5ca50050911744506ac9098d02cb558f5178ca8f6700be83a6e60e9ce4b5ee37` | ✅ |
| bridge_reconciler.py | 41c404ca | `41c404cabbdee52e168ac47dd982b937714ff61e4111432a3cf308255bd47cea` | ✅ |
| bridge_minter.py | d77c5530 | `d77c55305a5b301daa6bd0b0f3b58048b1a55fb12374d681ee2937aefb12610c` | ✅ |
| emit_api.py | 6bf41034 | `6bf41034e3901789956e161db72e6c3364acf5f951235fa266ad050636fd325f` | ✅ |
| workcell_events.json | 5c50e435 | `5c50e435c8d71c86eab67d19eff36850b96e675c441ce598ca544c977db29fa1` | ✅ |

収集時点の repo HEAD: egl `DE-0482` 記帳済 / twoder `739c8ba`

---

## 01_bridge/ — §2 本体 + oracle/テストハーネス一式

`patch_bridge.py` / `bridge_reconciler.py` / `bridge_minter.py`（twoder 正本）

`tests/` = bridge 系を import・参照する全ファイル（twoder/regression を全走査して抽出。
`grep -rln "patch_bridge\|bridge_minter\|bridge_reconciler"` の結果と一致）:

| ファイル | 役割 |
|---|---|
| `verify_reconciler_A.py` | §2-A reconciler oracle |
| `verify_minter_B.py` | §2-B minter oracle（18/18 throwaway） |
| `verify_throwaway_first.py` | throwaway-first 規律の検証 |
| `gate_s4_energization.py` | §4 energization 反実仮想 gate（11 injection） |
| `gate_reconciler_readonly.py` | reconciler の read-only 性を AST で証明 |
| `jrev0010_attacks.py` | JREV-0010 の A1..A6 攻撃 |
| `test_harness_reverify.py` | LAYER-3 直接再検証ハーネス |

> **R4（CORRECTION 権限根）と R1-5 の novel attack を書く際の注意**: `gate_s4_energization.py`
> と `gate_reconciler_readonly.py` は JREV-0010 で「恒久機構として必須」と判定されたもの。
> 修復後もこの2つが緑であることが terminal 条件に含まれます。

## 02_emit_api/ — C 層（実行観測 SoR）

- `emit_api.py`（`6bf41034…`。**Qwen 生成バイトそのもの**。D-2 により Claude は編集不可）
- `emit_api.PROVENANCE.txt`（昇格記録。source run `20260719T131242Z-028d21d9`、
  sha256 == RESULT_PACKET final_disk_sha256 == model_reply_sha256 のバイト一致検証済）
- `test_emit_api.py` = **契約テスト**。正本は `/srv/workcell/specs/M1_tests/test_emit_api.py`
  （packet の `immutable_test_files` が指す側。run の ws 内コピーではなく spec 側を採録）
- `workcell_events.json`（`5c50e435…`。**kinds 10種のみ**で writer registry は不在＝
  DE-0475 WA-2 / DE-0474 束縛1 が現状 governance-only であることの一次証拠）

## 03_packet_example/ — runner packet 形式の実例

`JOB03.json` = S0.2（status_views）で実際に走った packet。`test_cmd` は
**配列形式**（`["python3","-m","pytest","-x","-q","test_status_views.py"]`）である点、
`immutable_test_files` が `{ws内ファイル名: 絶対パス}` の写像である点に注意。
参考として JOB03 が指す immutable test 実体も同梱（`REFERENCE_` 前置）。

## 04_energization/ — R1-5 CORRECTION 起草用

- `ENERGIZATION_OBSERVATIONS.jsonl`（**無改変**。7 record = PA 3 + RECONCILIATION_BALANCED 4）
- `LINE_INDEX_AND_RECORD_HASH_NOTE.md` ← **必読**
- `REFERENCE_ENERGIZATION_LEDGER.jsonl`（参考。ADJUDICATION 2件。repo_identity を持つのは
  こちらだけ、という非対称が R1 の設計に効くため同梱）

---

## ⚠ 依頼の前提と実測が食い違った点（1件）

依頼文: 「ENERGIZATION_OBSERVATIONS.jsonl の PA 3件（R1-5 の CORRECTION 起草に**原
record_hash** が要る）」

**実測: この event store の record に `record_hash` 場は存在しません。**
全7 record の key は `task_id` / `kind` / `payload` / `ts` / `identity` のみで、
`grep -c record_hash` = 0 です。C 層（emit_api EventStore）は `record_hash` を持ちますが、
この energization 用 store は **C 層ではなく §2 bridge 専用の別ファイル**で、
hash-chain も segment も持ちません。

代替として、各行の生バイトの sha256 を私が計算し `LINE_INDEX_AND_RECORD_HASH_NOTE.md`
に付しました。**これは原記録の一部ではなく本日の計算値**です。CORRECTION がどの識別子で
原 record を指すか（この計算値 / 行番号 + task_id + token_id + ts / あるいは記録側に
record_hash を追加する R を1本足す）は設計側の裁定事項として差し戻します。
DE-0474 束縛3「cross-store 参照は照合可能形式に限る」との関係も併せてご判断ください。
記帳: DE-0483。
