"""FIX-01c 開示欠陥の実証: live apply 経路が書込み後に ValueError で停止し、
PATCH_APPLICATION を記録しないまま作業ツリーを汚すか。"""
import os, hashlib, tempfile, subprocess
import patch_bridge as pb, bridge_minter as bm
import tfix   # テストの生成ヘルパを再利用（新規実装ではない）

tmp = tempfile.mkdtemp(prefix='defect_')
repo = tfix.make_repo(tmp, 'target')
real = os.path.realpath(repo)
orig = open(os.path.join(repo, 'impl.py'), 'rb').read()

new = b'patched\n'
fp = hashlib.sha256(new).hexdigest()
art = {'diff': new.decode(), 'base_commit': subprocess.run(['git','-C',repo,'rev-parse','HEAD'],
       capture_output=True, text=True).stdout.strip(), 'fingerprint': fp, 'files': {'impl.py': new.decode()}}

events = []
def recorder(task_id, kind, payload, ts, identity=None):
    events.append({'kind': kind, 'payload': payload, 'task_id': task_id, 'ts': ts, 'identity': identity})
    return True

# 契約どおり repo 場を持つ balanced proof と adjudication を用意し、実 minter で鋳造
head = art['base_commit']
log = [
  {'kind':'ENERGIZATION_ADJUDICATION','payload':{'adjudication_id':'ADJ-1','authority_owner':'TAKA',
   'granted_by':'TAKA','attribution':'TAKA','item_id':'IT-1','repo_identity':'target','repo_realpath':real,
   'base_commit':head,'fingerprint':fp,'allowed_files':['impl.py'],'expires_at':'2099-01-01T00:00:00Z'}},
  {'kind':'RECONCILIATION_BALANCED','payload':{'balanced':True,'baseline':True,'head':head,
   'repo_identity':'target','repo_realpath':real,'orphans_event_without_git':[],
   'orphans_git_without_event':[],'checked_files':[],'applies_seen':0}},
]
req = {'item_id':'IT-1','task_id':'T','trace_id':'TR','repo_identity':'target','repo_realpath':real,
       'base_commit':head,'allowed_files':['impl.py'],'fingerprint':fp,'token_id':'TOK-1',
       'adjudication_id':'ADJ-1'}
tok = bm.mint_real_energize(req, log, repo, now_ts='2026-07-21T00:00:00Z')
print('token minted OK')

try:
    pb.apply_patch_bounded(repo, art, ['impl.py'], recorder, 'T', '2026-07-21T00:00:00Z',
                           energize=tok, expected_base=head, expected_fingerprint=fp)
    print('apply 成功（欠陥なし）')
except ValueError as e:
    print('★ ValueError:', e)

on_disk = open(os.path.join(repo, 'impl.py'), 'rb').read()
print('作業ツリーは書き換わったか :', on_disk != orig, '(disk=%r)' % on_disk)
print('PATCH_APPLICATION 記録件数 :', sum(1 for e in events if e['kind']=='PATCH_APPLICATION'))
print('→ 未記録書込みの成立      :', on_disk != orig and not any(e['kind']=='PATCH_APPLICATION' for e in events))
